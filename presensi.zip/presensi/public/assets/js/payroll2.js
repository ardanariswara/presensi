(function ($) {
    "use strict";
  console.log('payroll.js loaded')
    var HARI_KERJA = 20,
            JAM_KERJA = 8,
            MULTPLY_LEMBUR = 1.5,
            MULTPLY_TELAT = 2,
            $attrPendapatan = $('tbody#attr-penambah').find('input[type=text]'),
            $attrPotongan = $('tbody#attr-pengurang').find('input[type=text]'),
            $gaji_pokok = $('#gaji_pokok').val(),
            $pajak_input = $('#tax'),
            SITE_URL = window.location.origin,
            JKK_PERUSAHAAN = 0.24 / 100,
            JKM_PERUSAHAAN = 0.3 / 100,
            JHT_PERUSAHAAN = 3.7 / 100,
            JHT_EMPLOYEE = 2 / 100,
            TUNJANGAN_KK = 2 / 100,
            KSHT_PERUSAHAAN = 4 / 100,
            KSHT_EMPLOYEE = 1 / 100;

    var Payroll = {
        init: function () {
            var self = this;
            console.log('KK- ' + self.countTunjanganKK())
            console.log('BPJS- ' + self.countTunjanganBPJS())

            self.bootUp();

        },
        bootUp: function () {
            this.lembur();
            this.telat();
            this.tax();
            this.totalGaji();
            this.trHover();
            this.removeAttr();
            this.refresh();
            this.attrChange();
            this.print();
            this.totalPendapatan();
            this.totalPotongan();


        },
        lembur: function () {
            var $lembur_input = $('#lembur'),
                    $overtime = $('#overtime').val(),
                    $lembur = Math.floor(($gaji_pokok / HARI_KERJA / JAM_KERJA) * MULTPLY_LEMBUR * $overtime);

            $lembur_input.val($lembur);

            return $lembur;
        },
        telat: function () {
            var $telat_input = $('#telat'),
                    $latetime = $('#latetime').val(),
                    $telat = Math.floor(($gaji_pokok / HARI_KERJA / JAM_KERJA) * MULTPLY_TELAT * $latetime);

            $telat_input.val($telat);

            return $telat;
        },
        attrPendapatan: function () {
            var $total = 0;

            $('tbody#attr-penambah').find('input[type=text]').each(function (i, v) {
                if ($(v).data('fix') == 1) {
                    $total += parseInt($(v).val()) * 12;
                } else {
                    $total += parseInt($(v).val());
                }
            })
            return $total;
        },
        takeHomePay: function () {

            return this.gajiSetahun() + (this.attrPendapatan() + this.lembur()) + this.countTunjanganKK() + this.countTunjanganBPJS();
        },
        gajiSetahun: function () {
            return ($gaji_pokok - this.telat()) * 12
        },
        taxCount: function () {
            if (this.pendapatanKenaPajak() < 50000000) {

                return Math.floor(this.pendapatanKenaPajak() * (5 / 100));

            } else if (this.pendapatanKenaPajak() >= 50000000 && this.gajiSetahun() < 250000000) {

                return Math.floor(this.pendapatanKenaPajak() * (15 / 100));

            } else if (this.pendapatanKenaPajak() >= 250000000 && this.gajiSetahun() < 500000000) {

                return Math.floor(this.pendapatanKenaPajak() * (25 / 100));

            } else if (this.pendapatanKenaPajak() > 500000000) {

                return Math.floor(this.pendapatanKenaPajak() * (30 / 100));

            }
        },
        tax: function () {
            // if($gaji_pokok < 3000000){
            if (this.totalPendapatan() < 3000000) {
                var tax_value = 0;
            } else {
                var tax_value = Math.floor(this.taxCount() / 12);
            }
            $pajak_input.val(tax_value < 0 ? 0 : tax_value);
            return tax_value < 0 ? 0 : tax_value;
        },
        biayaJabatan: function () {
            return Math.floor(this.takeHomePay() * (5 / 100));
        },
        pendapatanKenaPajak: function () {
            return this.takeHomePay() - this.biayaJabatan() - 36000000 - this.countTunjanganBPJSEmp() - this.countTunjanganKKSEmp();
        },
        totalPendapatan: function () {
            var $total = 0;

            var $pdp_table = $('table#tambah').find('input[type=text]');

            $pdp_table.each(function (i, v) {
                $total += parseInt($(v).val());
            })

            $('input#total_earning').val($total);
//			console.log($total)
            return $total;
        },
        totalPotongan: function () {
            var $total = 0;

            var $ptg_table = $('table#potongan').find('input[type=text]');
            // console.log($ptg_table);
            $ptg_table.each(function (i, v) {
                $total += parseInt($(v).val());
            })

            $('input#total_deduction').val($total);

            return $total;
        },
        totalGaji: function () {
            var $totalGaji = this.totalPendapatan() - this.totalPotongan();

            $('#total_gaji').val($totalGaji);
            return $totalGaji;
        },
        save: function (url) {
            var items_earning = [];
            var items_deduction = [];
            // var $url = '{{route('admin.payroll.save', [$findUser->id])}}';
            var $url = url;
            $('tbody#attr-penambah tr#attr').each(function () {
                var row = {};
                $(this).find('input,select,textarea').each(function () {
                    if ($(this).is(':checkbox')) {
                        if ($(this).is(':checked')) {
                            row[$(this).attr('name')] = 1;
                        }
                        else {
                            row[$(this).attr('name')] = 0;
                        }
                    }
                    else {
                        row[$(this).attr('name')] = $(this).val();
                    }
                });
                items_earning.push(row);
            });
            $('tbody#attr-pengurang tr').each(function () {
                var row = {};
                $(this).find('input,select,textarea').each(function () {
                    if ($(this).is(':checkbox')) {
                        if ($(this).is(':checked')) {
                            row[$(this).attr('name')] = 1;
                        }
                        else {
                            row[$(this).attr('name')] = 0;
                        }
                    }
                    else {
                        row[$(this).attr('name')] = $(this).val();
                    }
                });
                items_deduction.push(row);
            });

            // console.log($('input#total_earning').val());
            $.post($url, {
                overtime: $('input#lembur').val(),
                user_id: $('input#user_id').val(),
                total_earnings: $('input#total_earning').val(),
                tax: $('input#tax').val(),
                late: $('input#telat').val(),
                total_deductions: $('input#total_deduction').val(),
                date: $('select#month').val() + '-' + $('select#year').val(),
                jht_perusahaan: $('input#perusahaan_jht').val(),
                jkk_perusahaan: $('input#perusahaan_jkk').val(),
                jkm_perusahaan: $('input#perusahaan_jkm').val(),
                jht_karyawan: $('input#karyawan_jht').val(),
                kesehatan_perusahaan: $('input#perusahaan_kesehatan').val(),
                kesehatan_karyawan: $('input#karyawan_kesehatan').val(),
                attribute_earning: JSON.stringify(items_earning),
                attribute_deduction: JSON.stringify(items_deduction)
            })
                    .done(function (response) {
                        window.location.reload();
//                    console.log(response)
                    })
        },
        update: function (url) {
            var items_earning = [];
            var items_deduction = [];
            // var $url = '{{route('admin.payroll.save', [$findUser->id])}}';
            var $url = url;
            $('tbody#attr-penambah tr#attr').each(function () {
                var row = {};
                $(this).find('input,select,textarea').each(function () {
                    if ($(this).is(':checkbox')) {
                        if ($(this).is(':checked')) {
                            row[$(this).attr('name')] = 1;
                        }
                        else {
                            row[$(this).attr('name')] = 0;
                        }
                    }
                    else {
                        row[$(this).attr('name')] = $(this).val();
                    }
                });
                items_earning.push(row);
            });
            $('tbody#attr-pengurang tr').each(function () {
                var row = {};
                $(this).find('input,select,textarea').each(function () {
                    if ($(this).is(':checkbox')) {
                        if ($(this).is(':checked')) {
                            row[$(this).attr('name')] = 1;
                        }
                        else {
                            row[$(this).attr('name')] = 0;
                        }
                    }
                    else {
                        row[$(this).attr('name')] = $(this).val();
                    }
                });
                items_deduction.push(row);
            });
            $.post($url, {
                overtime: $('input#lembur').val(),
                user_id: $('input#user_id').val(),
                total_earnings: $('input#total_earning').val(),
                tax: $('input#tax').val(),
                late: $('input#telat').val(),
                total_deductions: $('input#total_deduction').val(),
                jht_perusahaan: $('input#perusahaan_jht').val(),
                jkk_perusahaan: $('input#perusahaan_jkk').val(),
                jkm_perusahaan: $('input#perusahaan_jkm').val(),
                jht_karyawan: $('input#karyawan_jht').val(),
                kesehatan_perusahaan: $('input#perusahaan_kesehatan').val(),
                kesehatan_karyawan: $('input#karyawan_kesehatan').val(),
                date: $('select#month').val() + '-' + $('select#year').val(),
                attribute_earning: JSON.stringify(items_earning),
                attribute_deduction: JSON.stringify(items_deduction)
            })
                    .done(function (response) {
                        window.location.reload();
                        // console.log(response) 
                    })
        },
        addAttrEarning: function () {
            $.get(SITE_URL + '/admin/payroll/attr-earning')
                    .done(function (response) {
                        console.log(response);
                        var source = $("#template-attr").html();
                        var template = Handlebars.compile(source);


                        $('table#tambah tbody:last').append(template({items: response}));


                        Payroll.bootUp();
                        $('select#attributes').on({
                            change: function () {
                                var key = $(this).find(':selected').data('key');
                                // alert(response[key].value);
                                $(this).closest('tr').find('td input#attribute_values').val(response[key].value);
                                // console.log($(this).closest('tr').find('td input#val_earning').val());

                                Payroll.bootUp();
                            }
                        })


                    })
        },
        addAttrDeduction: function () {
            $.get(SITE_URL + '/admin/payroll/attr-deduction').done(function (response) {

                console.log(response);
                var source = $("#template-attr").html();
                var template = Handlebars.compile(source);


                $('table#potongan tbody:last').append(template({items: response}));

                Payroll.bootUp();
                $('select#attributes').on({
                    change: function () {
                        var key = $(this).find(':selected').data('key');
                        // alert(response[key].value);
                        $(this).closest('tr').find('td input#attribute_values').val(response[key].value);
                        // console.log($(this).closest('tr').find('td input#val_earning').val());
                        Payroll.bootUp();
                    }
                })
            })
        },
        trHover: function () {
            $('tr#attr').on({
                mouseover: function () {
                    $(this).find('div').show();
                },
                mouseout: function () {
                    $(this).find('div').hide();
                }
            })
        },
        removeAttr: function () {
            var $attr = $('a#remove-attr');
            $attr.on({
                click: function () {
                    $(this).parent().parent().parent().remove();

                    Payroll.bootUp();
                }
            })
        },
        refresh: function () {
            var $attr = $('#refresh');
            $attr.on({
                click: function () {
                     Payroll.countTunjanganKK();
                     Payroll.countTunjanganBPJS();
                     Payroll.countTunjanganKKSEmp();
                     Payroll.countTunjanganBPJSEmp();
                     Payroll.countKshtCompany();
                     Payroll.countKshtEmployee();

                    Payroll.bootUp();
                }
            })
        },
        attrChange: function () {
            $('tbody#attr-penambah').find('input[type=text]').on({
                change: function () {

                    Payroll.bootUp();
                }
            });
            $('tbody#attr-pengurang').find('input[type=text]').on({
                change: function () {

                    Payroll.bootUp();
                }
            });
        },
        print: function () {
            var $button = $('button#print');
            $button.on({
                click: function () {
                    window.open($(this).data('url'), 'mywin', 'left=20,top=20,width=1000,height=700,toolbar=0,resizable=0');
                }
            })
        },
        countTunjanganKK: function () {
            var $jht = parseInt($('#perusahaan_jht').val());
            var $jkk = parseInt($('#perusahaan_jkk').val());
            var $jkm = parseInt($('#perusahaan_jkm').val());

            return ($jht + $jkk + $jkm) * 12;
        },
        countTunjanganBPJS: function () {

            var $kesehatan = parseInt($('#perusahaan_kesehatan').val());
            return $kesehatan * 12;
        },
        countTunjanganKKSEmp: function () {
            var $jht = parseInt($('#karyawan_jht').val());
            return $jht * 12;
        },
        countTunjanganBPJSEmp: function () {
            var $kesehatan = parseInt($('#karyawan_kesehatan').val());
            return $kesehatan * 12;
        },
        countKshtCompany: function () {
            var $amount = Math.floor($gaji_pokok * KSHT_PERUSAHAAN);

            // $('#perusahaan_kesehatan').val($amount);
            // $('#perusahaan_kesehatan1').val($amount);
            Payroll.bootUp();

            return $amount;
        },
        countKshtEmployee: function () {
            var $amount = Math.floor($gaji_pokok * KSHT_EMPLOYEE);

            // $('#karyawan_kesehatan').val($amount);
            Payroll.bootUp();

            return $amount;
        }
    }

    window.Payroll = Payroll;
})(jQuery);
