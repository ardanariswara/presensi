<?php
/**
 * Created by PhpStorm.
 * User: ardiansyah
 * Date: 11/5/14
 * Time: 2:33 AM
 */

namespace App\Modules\Dashboard\Controllers;


use Illuminate\Support\Facades\View;

class AdminDashboardController extends \BaseController{

    public function index()
    {
        return View::make('dashboard::admin.index');
    }

} 