<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 01/11/14
 * Time: 15:49
 */

namespace App\Modules\Dashboard\Controllers;


use Illuminate\Support\Facades\View;

class MemberDashboardController extends \BaseController {

    public function index()
    {
        return View::make('dashboard::member.index');
    }

} 