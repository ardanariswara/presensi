<?php

Route::group(['prefix' => 'admin', 'before' => ['auth','admin']], function(){

    Route::get('/', ['uses' => 'App\Modules\Dashboard\Controllers\AdminDashboardController@index', 'as' => 'admin.dashboard']);

});

Route::group(['before' => 'auth'], function(){

    Route::get('/', ['uses' => 'App\Modules\Dashboard\Controllers\MemberDashboardController@index', 'as' => 'dashboard']);

});