@extends('layouts.default')

@section('content')

<div class="col-sm-12" style="height: 200px;">
<!--
    <div class="form-group text-center">
        @if(Session::get('signin'))
        <button class="btn btn-danger btn-lg-max" onclick=" return location.href = '{{ route('member.presensi.signout', [Auth::user()->id]) }}' ">Pulang</button>
        @else
        <button class="btn btn-default btn-lg" onclick=" return location.href = '{{ route('member.presensi.signin', [Auth::user()->id]) }}' ">Presensi</button>
        @endif

    </div>-->
<!--    <p class="pull-right visible-xs">
        <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
    </p>
    <div class="jumbotron">
        <h1>Hello, world!</h1>
        <p>This is an example to show the potential of an offcanvas layout pattern in Bootstrap. Try some responsive-range viewport sizes to see it in action.</p>
    </div>-->

</div><!--/.col-xs-12.col-sm-9--> 

@stop