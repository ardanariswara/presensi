@extends('layouts.default')

@section('content')

<div class="col-sm-12" style="height: 200px;">
<!--    <p class="pull-right visible-xs">
        <button type="button" class="btn btn-primary btn-xs" data-toggle="offcanvas">Toggle nav</button>
    </p>
    <div class="jumbotron">
        <h1>Hello, world!</h1>
        <p>This is an example to show the potential of an offcanvas layout pattern in Bootstrap. Try some responsive-range viewport sizes to see it in action.</p>
    </div>-->

</div><!--/.col-xs-12.col-sm-9--> 

@stop