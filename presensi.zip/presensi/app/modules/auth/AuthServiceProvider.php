<?php namespace App\Modules\Auth;

use Illuminate\Support\ServiceProvider;

class AuthServiceProvider extends ServiceProvider {

  public function register()
  {
      $this->app->bind(
          'App\Modules\Auth\Repositories\AuthRepository'
      );
  }

}
