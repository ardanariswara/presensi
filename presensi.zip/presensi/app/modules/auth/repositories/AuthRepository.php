<?php
namespace App\Modules\Auth\Repositories;

class AuthRepository {

  public function all()
  {
    return "all data";
  }

}
