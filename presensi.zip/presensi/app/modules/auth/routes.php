<?php

Route::get('login', 'App\Modules\Auth\Controllers\AuthController@getLogin');
Route::get('logout', 'App\Modules\Auth\Controllers\AuthController@getLogout');
Route::post('login', 'App\Modules\Auth\Controllers\AuthController@postLogin');
