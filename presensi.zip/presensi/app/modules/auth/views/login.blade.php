@extends('layouts.login')

@section('content')

<div class="col-md-4 col-md-offset-4">
    <div class="panel panel-default">
        <div class="panel-heading">
            <div class="row-fluid user-row">
                <a href="http://insfilo.com"> <img src="{{ asset('assets/img/logo.png') }}" class="img-responsive" alt="Conxole Admin"/></a>
            </div>
        </div>
        <div class="panel-body">
            {{ Form::open(['url' => 'login', 'class' => 'form-signin']) }}
                <fieldset>
                    @if( $errors->any())
                    @foreach($errors->all() as $error)
                    <div class="alert alert-dismissable alert-danger">
                        {{ $error }}
                    </div>
                    @endforeach
                    @endif
                    {{ Form::email('email',null, ['class' => 'form-control']) }}
                    {{ Form::password('password', ['class' => 'form-control']) }}
                    <br></br>
                    <button class="btn btn-lg btn-primary btn-block" type="submit">Login</button>
                </fieldset>
            {{ Form::close() }}
        </div>
    </div>
</div>



@stop