<?php
namespace App\Modules\Auth\Forms;

use Laracasts\Validation\FormValidator;

class AuthForm extends FormValidator {

  protected $rules = [
      'email' => 'required',
      'password' => 'required'
  ];

}
