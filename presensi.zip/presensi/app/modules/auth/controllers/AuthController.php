<?php namespace App\Modules\Auth\Controllers;
//use Auth, Input, Redirect, View;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use App\Modules\Auth\Repositories\AuthRepository;
use App\Modules\Auth\Forms\AuthForm;

/**
 * Authentication controller
 * @author Boris Strahija <bstrahija@gmail.com>
 */
class AuthController extends \BaseController {

    protected $auth;

    protected $form;


    public function __construct(AuthRepository $authRepository, AuthForm $authForm)
    {
        $this->auth = $authRepository;

        $this->form = $authForm;
    }
    /**
     * Display login screen
     * @return View
     */
    public function getLogin()
    {
		return View::make('auth::login');
    }

    /**
     * Attempt to login
     * @return Redirect
     */
    public function postLogin()
    {
        $this->form->validate(\Input::all());

        $credentials = array(
            'email' => Input::get('email'),
            'password' => Input::get('password'),
        );
        if (Auth::attempt($credentials))
        {
            if(Auth::user()->hasRole('Admin')){
                return Redirect::route('admin.dashboard');
            }
            return Redirect::route('member.presensi.index');

        }
        return Redirect::to('login')->withErrors('errors', 'Login failed!');
    }

    /**
     * Log a user out
     * @return Redirect
     */
    public function getLogout()
    {
        Auth::logout();
        return Redirect::to('login');
    }
}
