<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 02/11/14
 * Time: 10:34
 */

namespace App\Modules\Calendar\Models;


use Illuminate\Database\Eloquent\Model;
use Laracasts\Presenter\PresentableTrait;

class Calendar extends Model {

    use PresentableTrait;

    protected $table = 'calendar';

    protected $guarded = ['id'];

    protected $fillable = ['title', 'description', 'start', 'end', 'jenis'];

    protected $presenter = 'App\Modules\Calendar\Presenters\CalendarPresenter';

} 