<?php

Route::group(['prefix' => 'admin', 'namespace' => 'App\Modules\Calendar\Controllers\Admin', 'before' => ['auth', 'admin']], function(){

    Route::resource('calendar','CalendarController');
    Route::get('calendar/edit/{id}', 'CalendarController@edit');
    Route::post('calendar/{id}/drop', 'CalendarController@quickDrop');

});