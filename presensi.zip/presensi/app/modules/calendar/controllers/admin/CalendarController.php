<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 02/11/14
 * Time: 10:27
 */

namespace App\Modules\Calendar\Controllers\Admin;

use App\Modules\Calendar\Repositories\CalendarRepositories;
use App\Modules\Calendar\Forms\CalendarForm;
use Carbon\Carbon;
use Illuminate\Support\Facades\Input;

class CalendarController extends \BaseController{

    protected $calendar;
    protected $form;

    public function __construct(CalendarRepositories $calendarRepository,CalendarForm $formCalendar)
    {
        $this->calendar = $calendarRepository;
        $this->form = $formCalendar;
    }

    public function index() {

        $eventsAll = $this->calendar->all();
        $events = $this->calendar->getEvents();
        $today = date('Y-m-d');
        return \View::make('calendar::index', compact('events','eventsAll', 'today'));
    }

    public function create() {
        $editMode = false;
        $start = \Input::get('start');
        $startFormatted = Carbon::parse($start)->format('j F Y');
        return \View::make('calendar::modal_create', compact('start', 'startFormatted', 'editMode'));
    }

    public function store() {
        $input = Input::all();

        $create = $this->calendar->store($input);

        return $create;
    }

    public function edit($id)
    {
        $calendar = $this->calendar->find($id);
        $startFormatted = Carbon::parse($calendar->start)->format('j F Y');
        return \View::make('calendar::modal_edit', compact('calendar', 'startFormatted', 'editMode'));
    }

    public function update($id)
    {
        $input = \Input::all();

        $update = $this->calendar->update($id, $input);
        unset($input['_token']);
        $message = [
            'old' => $input,
            'new' => $this->calendar->getEventById($id)
        ];

//        return $message;
//        $message = $this->calendar->all();
        return $message;
    }

    public function quickDrop($id)
    {
        $input = \Input::all();

        $update = $this->calendar->quickUpdate($id, $input);
    }

    public function destroy($id)
    {
        $this->calendar->delete($id);
    }

} 