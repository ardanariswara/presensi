
<script>
    $(function() {
        $('#event-calendar').modal('show');
        /*$('#datepicker input').datepicker({
            format: "yyyy-mm-dd",
            todayBtn: true,
            orientation: "top right",
            todayHighlight: true
        });*/
        $('#datetimepicker6').datetimepicker();

        $('#modal-holder button#save').on('click', function() {
            console.log($('form').serialize());

//            location.reload(true);
            $.ajax({
                type: "PUT",
                url: "{{ route('admin.calendar.update', [$calendar->id]) }}",
                data: $('form').serialize()
            })
                .done(function(msg) {
                    var eventData;
//                console.log(eventData);
                    if (msg) {
                        console.log(msg)
                        eventDataNew = {
                            title: msg.new.title,
                            start: msg.new.start,
                            end: msg.new.end,
                            id: msg.new.id,
                            description: msg.new.description
//                                backgroundColor: 'red'
                        };
                        $('#calendar').fullCalendar('removeEvents', msg.new.id);
                        $('#calendar').fullCalendar('renderEvent', eventDataNew);
//                            $('#calendar').fullCalendar('refetchEvents');
                        $('#event-calendar').modal('hide');
                    }
                });
        })

        $('#modal-holder button#delete').on('click', function()
        {
            $.ajax({
                type: "DELETE",
                url: "{{ route('admin.calendar.destroy', [$calendar->id]) }}",
                data: $('form').serialize()
            })
                .done(function(msg) {

                    console.log(msg)

                    $('#calendar').fullCalendar('removeEvents', '{{$calendar->id}}');
                    $('#event-calendar').modal('hide');
//                        }
                });
        })
    })
</script>
<style>
    .datepicker{z-index:1151 !important;}
</style>

<div class="modal fade" id="event-calendar" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="box box-solid box-primary">
                <div class="box-header">
                    <h3 class="box-title">{{ $startFormatted }}</h3>
                    <div class="box-tools pull-right">
                        <a href="javascript:;"  data-dismiss="modal"><i class="glyphicon glyphicon-remove"></i></a>
                    </div>
                </div>
                <div class="box-body">
                    <form role="form">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Event</label>
                            <input type="text" class="form-control" name="title" id="title" placeholder="Event Title" value="{{$calendar->title}}">
                            <input type="hidden" name="start" id="start" value="{{$calendar->start}}">
                            <input type="hidden" name="end" id="end">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Keterangan</label>
                            <textarea rows="5" class="form-control" name="description" id="description">{{$calendar->description}}</textarea>
                        </div>
                        <div class="form-group" id="datepicker">
                            <label>Event Selesai</label>
                            <input type='text' class="form-control" name="end" id="datetimepicker6" value="{{$calendar->end}}" data-date-format="YYYY-MM-DD">
<!--                            <input type="text" type="text" class="form-control" name="end" id="end" value="{{$calendar->end}}">-->
                        </div>
                        <div class="form-group" id="datepicker">
                            <label>Event Selesai</label>
                            <select class="form-control" name="jenis" id="jenis">
                                <option value="1" {{ $calendar->jenis == 1 ? 'selected' : '' }}>Libur Nasional</option>
                                <option value="2" {{ $calendar->jenis == 2 ? 'selected' : '' }}>Libur Kantor</option>
                            </select>
                        </div>

                        <button type="button" id="save" class="btn btn-default">Simpan</button>
                        <button type="button" id="delete" class="btn btn-danger">Hapus</button>
                    </form>
                </div><!-- /.box-body -->
            </div>
        </div>
    </div>
</div>