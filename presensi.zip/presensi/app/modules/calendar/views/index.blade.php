@extends('layouts.default')

@section('content')



<div class="col-md-12">
    <div class="form-group pull-left">
        <h3>Calendar</h3>
    </div>
</div>
<div class="col-md-9">
    <div id='calendar'></div>
</div>
<div class="col-md-3">
    <div class="calendar-events">
        <ul class="list-unstyled events">
            @foreach($eventsAll as $event)
            <li data-start="{{ $event->start }}">
                <ul class="list-unstyled event-lists {{$event->present()->clasEventJenis}}">
                    <li class="event-title">{{ $event->title }}</li>
                    <li>{{ $event->description }}</li>
                    <li>{{ $event->present()->startDate }}</li>
                <!-- <li>{{ $event->present()->endDate }}</li> -->
                </ul>
            </li>
            @endforeach
        </ul>
    </div>

</div>

<div id="modal-holder"></div>

@stop

@section('scripts')
<script>

    $(function() {

        $('#modal-holder').append(JSON.parse('{{$events}}'));

        var today = new Date();
        var dd = today.getDate();
        var mm = today.getMonth() + 1; //January is 0!
        var yyyy = today.getFullYear();
        var base_url = '{{ Request::root() }}';
        $('#calendar').fullCalendar({
            header: {
                left: 'prev,next today',
                center: 'title',
                right: ''
            },
            defaultDate: '{{$today}}',
            selectable: true,
            selectHelper: true,
            eventDrop: function(event, delta, revertFunc) {
                $.post(base_url + '/admin/calendar/'+ event.id+'/drop', {start: event.start.format(), _token: '{{ csrf_token() }}' });

//                alert(event.title + " was dropped on " + event.start.format());

//                if (!confirm("Are you sure about this change?")) {
//                    revertFunc();
//                }

            },
            dayClick: function(date, jsEvent, view, start) {
                $('.loader').css('display', 'block');
                $.get('{{ Request::root(). '/admin/calendar/create' }}', {start: date.format()}, function(data) {
                    $('#modal-holder').html(data);
                    $('.loader').css('display', 'none');
                });

            },
            editable: true,
            eventLimit: true, // allow "more" link when too many events
            eventClick: function(calEvent, jsEvent, view) {

                $.get( base_url + '/admin/calendar/'+ calEvent.id+'/edit' , {title: calEvent.title, description: calEvent.description}, function(data) {
                    $('#modal-holder').html(data);
                });

            },
            events: {{$events}}


        });

        $(document).on('click', '.events>li', function(){
            // console.log($(this).data('start'));
            $('#calendar').fullCalendar('gotoDate', $(this).data('start'));
        })

    });

</script>
@stop