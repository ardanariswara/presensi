
<script>
    $(function() {
        $('#event-calendar').modal('show');
        /*$('#datepicker input').datepicker({
            format: "yyyy-mm-dd",
            todayBtn: true,
            orientation: "top right",
            todayHighlight: true
        });*/
        $('#datetimepicker6').datetimepicker();

        $('#modal-holder button#save').on('click', function() {
            console.log($('form').serialize());

//            location.reload(true);
            $.ajax({
                type: "POST",
                url: "{{ route('admin.calendar.store') }}",
                data: $('form').serialize()
            })
                .done(function(msg) {
                    var eventData;
//                console.log(eventData);
//                        if (msg) {
//                        console.log(msg)
                    eventData = {
                        title: msg.title,
                        start: msg.start,
                        end: msg.end,
                        description: msg.description,
                        id: msg.id
                    };
                    $('#calendar').fullCalendar('renderEvent', eventData, true); // stick? = true
                    $('#event-calendar').modal('hide');
//                        }
                });
        })
    })
</script>
<style>
    .datepicker{z-index:1151 !important;}
</style>

<div class="modal fade" id="event-calendar" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="box box-solid box-primary">
                <div class="box-header">
                    <h3 class="box-title">{{ $startFormatted }}</h3>
                    <div class="box-tools pull-right">
                        <a href="javascript:;"  data-dismiss="modal"><i class="glyphicon glyphicon-remove"></i></a>
                    </div>
                </div>
                <div class="box-body">
                    <form role="form">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Event</label>
                            <input type="text" class="form-control" name="title" id="title" placeholder="Event Title">
                            <input type="hidden" name="start" id="start" value="{{$start}}">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Keterangan</label>
                            <textarea rows="5" class="form-control" name="description" id="description"></textarea>
                        </div>

                        <div class="form-group" id="datepicker">
                            <label>Event Selesai</label>
                            <input type='text' class="form-control" name="end" id="datetimepicker6" value="{{$start}}" data-date-format="YYYY-MM-DD">
<!--                            <input type="text" type="text" class="form-control" name="end" id="end" value="{{$start}}">-->
                        </div>
                        <div class="form-group" id="datepicker">
                            <label>Jenis Event</label>
                            <select class="form-control" name="jenis" id="jenis">
                                <option value="1">Libur Nasional</option>
                                <option value="2">Libur Kantor</option>
                            </select>
                        </div>
                        
                        <button type="button" id="save" class="btn btn-default">Simpan</button>
                        <!-- <button class="btn btn-success" type="button">Success</button> -->
                    </form>
                </div><!-- /.box-body -->
            </div>
        </div>
    </div>
</div>
