<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 02/11/14
 * Time: 10:48
 */

namespace App\Modules\Calendar\Forms;

use Laracasts\Validation\FormValidator;
class CalendarForm extends FormValidator{

    protected $rules = [
        'title' => 'required'
    ];

} 