<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 06/11/14
 * Time: 14:02
 */

namespace App\Modules\Calendar\Presenters;


use Laracasts\Presenter\Presenter;
use Carbon\Carbon;

class CalendarPresenter extends Presenter {

    public function startDate()
    {
        return Carbon::parse($this->start)->format('j F Y');
    }

    public function endDate()
    {
        return Carbon::parse($this->end)->format('j F Y');
    }

    public function clasEventJenis()
    {
        switch ($this->jenis){
            case 1: return 'libur-nasional'; break;
            case 2: return 'libur-kantor'; break;
        }
    }

} 