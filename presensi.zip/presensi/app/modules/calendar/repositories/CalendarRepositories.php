<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 02/11/14
 * Time: 10:29
 */

namespace App\Modules\Calendar\Repositories;

use App\Modules\Calendar\Models\Calendar;
use Illuminate\Support\Facades\DB;

class CalendarRepositories {

    /**
     * @return mixed
     */
    public function all() {
        return Calendar::orderBy('start', 'asc')->get();
    }

    /**
     * @return string
     */
    public function getEvents() {
//        return Calendar::all();
        $events = DB::table('calendar')->select('start', 'end', 'title', 'description', 'id')->get();

        return json_encode($events);
    }

    /**
     * @param $id
     * @return int
     */
    public function delete($id) {
        return Calendar::destroy($id);
    }

    /**
     * @param $id
     * @return \Illuminate\Support\Collection|static
     */
    public function find($id) {
        return Calendar::find($id);
    }

    /**
     * @param $data
     * @return static
     */
    public function store($data) {

        return Calendar::create([
            'title' => $data['title'],
            'description' => $data['description'],
            'start' => $data['start'].date(' G:i:s'),
            'end' => $data['end'].date(' G:i:s'),
            'jenis' => $data['jenis']
        ]);
    }

    /**
     * @param $id
     * @param $data
     * @return \Illuminate\Support\Collection|static
     */
    public function update($id, $data) {

        $calendar = Calendar::find($id);
        $calendar->fill([
            'title' => $data['title'],
            'description' => $data['description'],
            'start' => $data['start'].date(' G:i:s'),
            'end' => $data['end'].date(' G:i:s'),
            'jenis' => $data['jenis']
        ]);
        $calendar->save();
        return $this->find($id);
    }

    /**
     * @param $id
     * @param $data
     * @return \Illuminate\Support\Collection|static
     */
    public function quickUpdate($id, $data) {

        $calendar = Calendar::find($id);
        $calendar->fill([
            'start' => $data['start'],
        ]);
        $calendar->save();
        return $this->find($id);
    }

    /**
     * @param $id
     * @return mixed
     */
    public function getEventById($id)
    {
        return $events = DB::table('calendar')->select('start', 'end', 'title', 'description', 'id')->first();
    }

} 