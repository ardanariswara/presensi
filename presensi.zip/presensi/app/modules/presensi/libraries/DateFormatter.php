<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 06/11/14
 * Time: 16:09
 */

namespace App\Modules\Presensi\Libraries;

use Carbon\Carbon;
use DateTime;
use DateInterval;

class DateFormatter {

    /**
     * @var \Carbon\Carbon
     */
    protected $carbon;

    /**
     *
     */
    public function __construct() {
//        setlocale(LC_TIME, 'Asia/Jakarta');
        $this->carbon = new Carbon();
    }

    /**
     * @return mixed
     */
    public static function inUnixDateTime()
    {
        $dt = Carbon::now();
        return $dt->getTimestamp();
    }

    /**
     * @return int
     */
    public static function inUnixDate()
    {
        $dt = new \DateTime(Carbon::now()->format('Y-m-d'));
        return $dt->getTimestamp();
    }

    /**
     * @param $unixtime
     * @param $format
     * @return string
     */
    public static function UnixToDate($unixtime, $format)
    {
        return Carbon::createFromTimeStamp($unixtime)->format($format);
    }

    /**
     * Create Unique Arrays using an md5 hash
     *
     * @param array $array
     * @return array
     */
    public static function arrayUnique($array, $preserveKeys = false)
    {
        // Unique Array for return
        $arrayRewrite = array();
        // Array with the md5 hashes
        $arrayHashes = array();
        foreach($array as $key => $item) {
            // Serialize the current element and create a md5 hash
            $hash = md5(serialize($item));
            // If the md5 didn't come up yet, add the element to
            // to arrayRewrite, otherwise drop it
            if (!isset($arrayHashes[$hash])) {
                // Save the current element hash
                $arrayHashes[$hash] = $hash;
                // Add element to the unique Array
                if ($preserveKeys) {
                    $arrayRewrite[$key] = $item;
                } else {
                    $arrayRewrite[] = $item;
                }
            }
        }
        return $arrayRewrite;
    }

    /**
     * @return array
     */
    public static function getAllDatesInMonth()
    {
        $aDates = array();
        $oStart = new \DateTime(date('Y-m-'.\Config::get('myapp.starting_date')));
        $oEnd = clone $oStart;
        $oEnd->add(new \DateInterval("P1M"));

        while($oStart->getTimestamp() < $oEnd->getTimestamp()) {
            $aDates[]['date'] = $oStart->getTimestamp();
            $oStart->add(new DateInterval("P1D"));
        }

        return $aDates;
    }

    public static function toUnixDate($date)
    {
        $dt = Carbon::parse($date);
        return $dt->getTimestamp();
    }

} 