<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 06/11/14
 * Time: 16:18
 */

namespace App\Modules\Presensi\Models;


use Illuminate\Database\Eloquent\Model;
use Laracasts\Presenter\PresentableTrait;

class Presensi extends Model {

    use PresentableTrait;

    /**
     * @var string
     */
    protected $table = 'presensi';

    /**
     * @var array
     */
    protected $fillable = ['user_id','signin', 'signout', 'notes', 'session', 'date', 'signin_date', 'is_signout'];

    /**
     * @var string
     */
    protected $presenter = 'App\Modules\Presensi\Presenters';

//    public function setSigninAttribute()
//    {
//
//        return $this->attributes['signin'] = DateFormatter::inTime();
//    }
//
//    public function setSignoutAttribute()
//    {
//        return $this->attributes['signout'] = DateFormatter::inTime();
//    }

    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function user()
    {
        return $this->belongsTo('App\Modules\User\Models\User', 'user_id');
    }

} 