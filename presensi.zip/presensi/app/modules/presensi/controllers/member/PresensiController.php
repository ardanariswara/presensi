<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 06/11/14
 * Time: 15:40
 */

namespace App\Modules\Presensi\Controllers\Member;

use App\Modules\Presensi\Repositories\PresensiRepository;
use App\Modules\Calendar\Repositories\CalendarRepositories;
use App\Modules\Presensi\Forms\PresensiForm;
use App\Modules\Presensi\Handlers\PresensiHandler;
use App\Modules\Presensi\Libraries\DateFormatter;
use Carbon\Carbon;

class PresensiController extends \BaseController{

    /**
     * @var \App\Modules\Presensi\Repositories\PresensiRepository
     */
    protected $presensi;

    /**
     * @var \App\Modules\Calendar\Repositories\CalendarRepositories
     */
    protected $calendar;

    /**
     * @var \App\Modules\Presensi\Forms\PresensiForm
     */
    protected $presensiForm;

    /**
     * @var \App\Modules\Presensi\Handlers\PresensiHandler
     */
    protected $handler;

    /**
     * @param PresensiRepository $presensiRepository
     * @param CalendarRepositories $calendarRepository
     * @param PresensiForm $presensiForm
     * @param PresensiHandler $presensiHandler
     */
    public function __construct(PresensiRepository $presensiRepository, CalendarRepositories $calendarRepository, PresensiForm $presensiForm, PresensiHandler $presensiHandler) {
        $this->presensi = $presensiRepository;
        $this->calendar = $calendarRepository;
        $this->presensiForm = $presensiForm;
        $this->handler = $presensiHandler;
    }


    /**
     * @return mixed
     */
    public function index()
    {
        $total_work = $this->presensi->getTotalWork();
        $dates = DateFormatter::getAllDatesInMonth();
        $late =  $this->presensi->getLateConverted();
        $overtime = $this->presensi->getOverTimeConverted();
        $data=  $this->presensi->getDataSignIn();
        $dd = array_merge($dates, $data);
        $uniqueArray = DateFormatter::arrayUnique($dd);
        $events = $this->calendar->all();
        $isSignin = $this->presensi->isSignin();
        $signevent = [];
        foreach($data as $d){
            $signevent[] = [
                'title' => 'sign in',
                'start' => DateFormatter::UnixToDate($d['signin'], 'Y-m-d H:i:s')
            ]; 
            $signevent[] = [
                'title' => 'sign out',
                'start' => DateFormatter::UnixToDate($d['signout'], 'Y-m-d H:i:s'),
                'color' => 'red'
            ];
        }
                // return $signevent;
        return \View::make('presensi::member.index', compact('events', 'data', 'late', 'overtime','dates', 'signevent', 'total_work', 'isSignin'));
    }

    /**
     * @param $id
     * @return mixed
     */
    public function signIn($id)
    {

        if($this->handler->whenUserHasSignIn() ==  true)
        {
            \Session::put('signin', md5(date('y-m-d')));

            $session = \Session::get('signin');

            $input = [
                'signin' => DateFormatter::inUnixDateTime(),
                'session' => $session ? $session : '',
                'date' => DateFormatter::inUnixDate()
            ];

            $this->presensi->signIn($id, $input);

            return \Redirect::back()->with('success', 'Anda Telah Login');
        }else{
            return \Redirect::back()->with('error', 'Anda Telah Presensi Hari Ini');
        }

    }

    /**
     * @param $id
     * @return mixed
     */
    public function signOut($id)
    {
        if($this->handler->whenUserHasSignOut() == true)
        {
            $session = \Session::get('signin');

            $input = [
                'signout' => DateFormatter::inUnixDateTime(),
            ];


            $this->presensi->signOut($id, $input); 
            $session = \Session::forget('signin');
            return \Redirect::back()->with('success', 'Anda Telah Logout');

        }else{
            return \Redirect::back()->with('error', 'Anda Telah Presensi Hari Ini');
        }
    }

    /**
     * @param $id
     * @return mixed
     */
    public function noted($id)
    {
        $start = \Input::get('start');
        $startFormatted = Carbon::parse($start)->format('j F Y');
        return \View::make('member.presensi._modalNoted', compact('startFormatted', 'start'));
    }

    /**
     * @param $id
     * @return int|string
     */
    public function storeNoted($id)
    {
        $dt = new \DateTime(\Input::get('starts'));
        return $dt->getTimestamp();
        return $this->presensi->getPresensiByDate($dt->getTimestamp());
    }

    public function year($month)
    {
        if($month > 0)
        {
            return date('Y');
        }else{
            return date('Y')-1;
        }
        
    }

    public function month($month)
    {
        if($month > 0)
        {
            return $month;
        }else{
            return 12;
        }
    }

} 