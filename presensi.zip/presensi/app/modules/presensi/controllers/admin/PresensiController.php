<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 07/11/14
 * Time: 16:48
 */

namespace App\Modules\Presensi\Controllers\Admin;


use App\Modules\Presensi\Libraries\DateFormatter;
use Barryvdh\Debugbar\Controllers\BaseController;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\View;
use App\Modules\User\Repositories\UserRepository;
use App\Modules\Calendar\Repositories\CalendarRepositories;
use App\Modules\Presensi\Repositories\PresensiRepository;

class PresensiController extends BaseController {

    protected $user;

    protected $calendar;

    protected $presensi;

    public function __construct(UserRepository $user, CalendarRepositories $calendar, PresensiRepository $presensiRepository)
    {
        $this->user = $user;

        $this->calendar = $calendar;

        $this->presensi = $presensiRepository;
    }


    public function index()
    {
        $users = $this->user->all();
        return View::make('presensi::admin.index', compact('users'));
    }

    public function show($id)
    {   
        $id = $id;
        $month = (isset($_GET['month'])) ? $_GET['month'] : date('m');     
        $year = (isset($_GET['year'])) ? $_GET['year'] : date('Y'); 
        $userData = $this->user->getDataUserSignInByDate($id,$month ,$year );

        $userDataSignIn = [];
        foreach ($userData as $usd){
            $userDataSignIn[] = [
                'title' => 'sign in',
                'start' => DateFormatter::UnixToDate($usd->signin, 'Y-m-d H:i:s'),
                'id' => $usd->id
            ];
            $userDataSignIn[] = [
                'title' => 'sign out',
                'start' => DateFormatter::UnixToDate($usd->signout, 'Y-m-d H:i:s'),
                'color' => 'red',
                'id' => $usd->id
            ];
        }

        unset($userData['presensi']);
        $users = $this->user->all();
        $events = $this->calendar->all();

        return View::make('presensi::admin.show', compact('userDataSignIn', 'users', 'events', 'id'));
    }

    public function edit($id)
    {
        $data = $this->presensi->find($id);

        return View::make('presensi::admin._modalUpdate',compact('data', 'id'));
    }

    public function newPresensi($id)
    {
        $tanggal = Input::get('tanggal');
        return View::make('presensi::admin._modalNew',compact('id', 'tanggal'));
    }

    public function update($id)
    {

        $input = Input::all();

//        return DateFormatter::toUnixDate($input['signin']);

        return $this->presensi->update($id, Input::all());

    }

    public function save($id)
    {
//        return $id;
         $input = Input::all();

        return $this->presensi->save($id, $input);
    }

    public function delete($id)
    {
        $this->presensi->delete($id);
        return $id;
    }

} 