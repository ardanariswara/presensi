@extends('layouts.default')

@section('content')

<div class="row2">
    <div class="col-md-12">
        @include('presensi::member.error')
        <div class="form-group pull-left">
            <h4>Presensi </h4>
        </div>
        <div class="form-group pull-right">
            @if(! $isSignin)
            <button class="btn btn-danger" onclick=" return location.href = '{{ route('member.presensi.signout', [Auth::user()->id]) }}' ">Pulang</button>
            @else
            <button class="btn btn-default" onclick=" return location.href = '{{ route('member.presensi.signin', [Auth::user()->id]) }}' ">Presensi</button>
            @endif

        </div>
    </div>
    <div class="col-md-9">
        <div id='calendar'></div>
    </div>
    <div class="col-md-3">
        <div class="time-box">

        </div>
        <table class="table table-bordered">
            <tr>
                <th class="text-center" style="width: 50%;">Late</th>
                <th class="text-center" style="width: 50%;">Overtime</th>
            </tr>
            <tr>
                <td class="text-center">{{ $late }}</td>
                <td class="text-center">{{ $overtime }}</td>
            </tr>
            <tr>
                <td class="text-center" colspan="2"><b>Total Work</b>: {{$total_work}}</td>
            </tr>
        </table>
    </div>
</div>

<div id="modal-holder"></div>

@stop

@section('scripts')
<script>

    $(document).ready(function() {

            var today = new Date();
            var dd = today.getDate();
            var mm = today.getMonth() + 1; //January is 0!
            var yyyy = today.getFullYear();
//        console.log(today.getDate());
            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month,agendaDay'
                },
                defaultDate: yyyy + '-' + mm + '-' + dd,
                defaultView: 'month',
                selectable: true,
                selectHelper: true,
                dayRender: function(date, cell) {
                    $.each( {{$events}}, function( key, value ) {
//                    console.log(value)
                var a = moment(value.end);
                var b = moment(value.start)._d;
                var start = moment(value.start);
                var diff =  a.diff(b, 'days');
                var end = new Date();
                end.setDate(b.getDate() + diff)
                if (date >= start && date <= end) {
                    if(value.jenis == '1'){
                        cell.css({ "background-color": "red", "color": "#fff #important"});
                    }else if(value.jenis == '2'){
                        cell.css({ "background-color": "blue", "color": "#fff #important"});
                    }

                }
            });
        },
        dayClick: function(date, jsEvent, view){
//                alert(date.format())
        $.get('{{ Request::root() }}'+'/member/activities/{{Auth::user()->id}}/noted', {start: date.format()}, function(data) {
            $('#modal-holder').html(data);
        });
    },
    //            weekNumbers: true,
    editable: true,
//            eventLimit: true, // allow "more" link when too many events
        events: {{ json_encode($signevent)}}

    });

    });

</script>
@stop