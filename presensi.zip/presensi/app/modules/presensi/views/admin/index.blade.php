@extends('layouts.default')

@section('content')

<div class="col-md-4">
    <div class="page-header">
        <h3>Kelola Presensi</h3>
    </div>
</div>
<!--<div class="col-md-12">
    <form class="form-inline">
        <div class="form-group">
            <label class="sr-only" for="exampleInputEmail2">Email address</label>
            <input type="email" class="form-control" id="exampleInputEmail2" placeholder="Enter email">
        </div>
        <div class="form-group">
            <label class="sr-only" for="exampleInputPassword2">Password</label>
            <input type="password" class="form-control" id="exampleInputPassword2" placeholder="Password">
        </div>
        <div class="checkbox">
            <label>
                <input type="checkbox"> Remember me
            </label>
        </div>
        <button type="submit" class="btn btn-default">Sign in</button>
    </form>
</div>-->
<div class="clearfix"></div>
<br>
<div class="col-lg-3">
    <ul class="nav nav-tabs tabs-left">
        @foreach($users as $key => $user)
        <li class="{{ $key == 0 ? 'actives' : '' }}"><a href="{{ route('admin.presensi.show', [$user->id])}}">{{ $user->fullname }}</a></li>
        @endforeach
    </ul>
</div>

<script>
    $(document).ready(function() {

    })
</script>
@stop