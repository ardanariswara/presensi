<?php

?>
@extends('layouts.default')

@section('content')

<div class="col-md-12">
    <div class="page-header">
        <h3>Kelola Presensi </h3>
    </div>
</div>
<div >
    <form method="get" class="col-md-12">
        <div class="form-group col-md-3">

            <select class="form-control" name="month" id="month">
                @for($month=1;$month<=12;$month++)
                <option value="{{ $month }}" {{ (isset($_GET['month']) && $_GET['month'] == $month) ? 'selected' : ''}}>{{date("F", mktime(0, 0, 0, $month, 10))}}</option>
                @endfor
            </select>

        </div>
        <div class="form-group col-md-3">
            <select class="form-control" name="year" id="year">
                @for($year=2012;$year<=date('Y');$year++)
                <option value="{{$year}}" {{ (isset($_GET['year']) && $_GET['year'] == $year) ? 'selected' : ''}}>{{$year}}</option>
                @endfor
            </select>
        </div>
        <div class="form-group col-md-3">
            <button class="btn btn-default">  Filter </button>
        </div>
    </form>
    <hr>
</div>

<div class="col-lg-3">
    <ul class="nav nav-tabs tabs-left">
        @foreach($users as $key => $user)
        <li class="{{ Request::segment(4) == $user->id ? 'active' : '' }}"><a href="{{ route('admin.presensi.show', [$user->id])}}">{{ $user->fullname }}</a></li>
        @endforeach
    </ul>
</div>
<div class="col-md-9">
    
    <div id="calendar">

    </div>
</div>
<div id="modal-holder"></div>
@stop

@section('scripts')

<script>
    $(window).ready(function(){
        console.log({{ json_encode($userDataSignIn) }})
            var today = new Date();
            var dd = today.getDate();
            var mm = $('#month').val();
            if(mm){
                             mm = today.getMonth();
            }
            var yyyy = $('#year').val();
//            var yyyy = today.getFullYear();
            $('#calendar').fullCalendar({
                header: {
                    left: 'today',
                    center: 'title',
                    right:  'prev,next'
                },
                defaultDate: yyyy + '-' + (mm  - 1) + '-' + dd,
                defaultView: 'month',
                selectable: true,
                selectHelper: true,
      
                //  weekNumbers: true,
                editable: true,
                dayClick: function(date, xEvent, jsEvent, view) {

                    console.log(xEvent);
                    $.get('{{Request::root()}}/admin/presensi/new/{{$id}}', { tanggal: date.format() })
                        .done(function(data){
                            $('#modal-holder').html(data);
                        });

                 
                },
                eventClick: function(calEvent, jsEvent, view, date) {
    
                    $.get('{{Request::root()}}/admin/presensi/edit/'+calEvent.id)
                        .done(function(data){
                            $('#modal-holder').html(data);
                        });
                },
                events: {{ json_encode($userDataSignIn) }}

            });
    })



</script>

@stop