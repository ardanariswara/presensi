<?php

use App\Modules\Presensi\Libraries\DateFormatter;
use Carbon\Carbon;
?>
<!--<link rel="stylesheet" href="{{asset('assets/css/bootstrap-datetimepicker.min.css')}}">-->
<!--<script src="{{asset('assets/js/bootstrap-datetimepicker.js')}}"></script>-->
<script>
    $(function() {
        $('#event-calendar').modal('show');

        $('#signout,#signin').datetimepicker({
            pick12HourFormat: true
        });

        $(document).on('click', 'button#save',function() {
//            console.log($('form').serialize());

//            location.reload(true);
            $.ajax({
                type: "POST",
                url: "{{ route('admin.presensi.update', [$id]) }}",
                data: $('form').serialize()
            })
                .done(function(msg) {
                    var eventData;
                console.log(msg);
//                        if (msg) {
//                        console.log(msg)
                    eventDataNew =[{
                            title: 'Sign in',
                            start: moment(msg.signin, 'X').format('YYYY-MM-DD HH:mm:SS'),
                            id: msg.id
                        },{
                            title: 'Sign out',
                            start: moment(msg.signout, 'X').format('YYYY-MM-DD HH:mm:SS'),
                            id: msg.id,
                            color:'red'
                        }];

                    console.log(eventDataNew)
//                    $('#calendar').fullCalendar('removeEvents', msg.id);
//                    $('#calendar').fullCalendar('renderEvent', eventDataNew); // stick? = true
                    $('#calendar').fullCalendar('removeEvents', msg.id);
                    $('#calendar').fullCalendar('addEventSource', eventDataNew);
                    $('#event-calendar').modal('hide');
//                        }
                });
        }).on('click', 'button#delete', function(){
                $.ajax({
                    type: "POST",
                    url: "{{ route('admin.presensi.delete', [$id]) }}"
                })
                    .done(function(msg) {
                        $('#calendar').fullCalendar('removeEvents', msg);
                        $('#event-calendar').modal('hide');
//                        }
                    });
            })
    })
</script>
<style>
    .datepicker{z-index:1151 !important;}
</style>

<div class="modal fade" id="event-calendar" tabindex="-1" role="dialog" data-backdrop="static" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="box box-solid box-primary">
                <div class="box-header">
                    <h3 class="box-title">Presensi {{Carbon::parse($data->created_at)->format('j F Y') }}</h3>
                    <div class="box-tools pull-right">
                        <a href="javascript:;"  data-dismiss="modal"><i class="glyphicon glyphicon-remove"></i></a>
                    </div>
                </div>
                <div class="box-body">
                    <form role="form">
                        <div class="form-group">
                            <!--<label for="exampleInputEmail1">Presensi</label>-->
                            <!--<input type="text" class="form-control" name="title" id="title" placeholder="Event Title">-->
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            <input type="hidden" name="date" value="{{Carbon::parse($data->created_at)->format('y-m-d') }}">
                            <input type="hidden" name="id" value="{{$data->id }}">
                        </div>

                        <div class="form-group" id="">
                            <label>Masuk</label>
                            <input type="text" type="text" class="form-control" name="signin" id="signin" data-date-format="YYYY-MM-DD HH:mm:SS" value="{{DateFormatter::UnixToDate($data->signin, 'Y-m-d H:i:s')}}">
                            <script type="text/javascript">
                                $(function() {
                                    $('#datetimepicker').datetimepicker();
                                });
                            </script>
                        </div>

                        <div class="form-group" id="">
                            <label>Pulang</label>
                            <input type="text" type="text" class="form-control" name="signout" id="signout" data-date-format="YYYY-MM-DD HH:mm:SS" value="{{DateFormatter::UnixToDate($data->signout, 'Y-m-d H:i:s')}}">
                        </div>

                        <button type="button" id="save" class="btn btn-default">Simpan</button>
                        <button type="button" id="delete" class="btn btn-danger">Hapus</button>
                    </form>
                </div><!-- /.box-body -->
            </div>
        </div>
    </div>
</div>

@section('scripts')

<script>
    $(function() {

    })
</script>

@stop