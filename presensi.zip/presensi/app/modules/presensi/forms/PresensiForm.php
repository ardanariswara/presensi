<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 06/11/14
 * Time: 15:45
 */

namespace App\Modules\Presensi\Forms;

use Laracasts\Validation\FormValidator;

class PresensiForm extends  FormValidator{

    protected $rules = [
        'session' => 'unique:presensi,session',
        'signout' => 'unique:presensi,signout',
        'signin' => 'required_if:signout,0'
    ];

    protected $messages = [
        'unique' => 'Hari ini anda Telah Presensi',
    ];

} 