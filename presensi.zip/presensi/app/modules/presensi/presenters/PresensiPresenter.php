<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 06/11/14
 * Time: 16:19
 */

namespace App\Modules\Presensi\Presenters;


use Laracasts\Presenter\Presenter;
use Carbon\Carbon;
use App\Modules\Presensi\Libraries\DateFormatter;

class PresensiPresenter extends Presenter {

    /**
     * @return string
     */
    public function signInTime()
    {
        return DateFormatter::UnixToDate($this->signin, 'H:i:s');
    }

    /**
     * @return int|string
     */
    public function signOutTime()
    {
        return ($this->signout != 0) ? DateFormatter::UnixToDate($this->signout, 'H:i:s') : 0 ;
    }

    /**
     * @return string
     */
    public function signDate()
    {
        return DateFormatter::UnixToDate($this->signin, 'j F Y');
    }

    /**
     * @return mixed
     */
    public function late()
    {
        $dt = Carbon::createFromTimeStamp($this->signin);
        $start_office = explode(':', \Config::get('myapp.office_start'));
        $intime = Carbon::createFromTime($start_office[0], $start_office[1], $start_office[2])->addMinutes(\Config::get('myapp.max_late'));
//        $intime = Carbon::createFromTime($start_office[0], $start_office[1], $start_office[2])->addMinutes(0);

        return DateFormatter::convertToHoursMins($intime->diffInMinutes($dt, false), '%02d.%02d');
    }

} 