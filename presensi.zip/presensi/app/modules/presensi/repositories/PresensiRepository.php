<?php

/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 01/11/14
 * Time: 16:31
 */

namespace App\Modules\Presensi\Repositories;

use App\Modules\Presensi\Libraries\DateFormatter;
use Carbon\Carbon;
use App\Modules\Presensi\Models\Presensi;

class PresensiRepository {

    /**
     * @param $id
     * @param $data
     * @return static
     */
    public function signIn($id, $data) {
        return Presensi::create([
                    'user_id' => $id,
                    'signin' => $data['signin'],
                    'date' => $data['date'],
                    'session' => \Session::get('signin'),
                    'signin_date' => date('Y-m-d'),
        ]);
    }

    /**
     * @param $id
     * @param $data
     * @param $session
     */
    public function signOut($id, $data) {
        $presensi = Presensi::where('user_id', '=', $id)->where('signin_date', '=', date('Y-m-d'))->update(array('signout' => $data['signout'], 'is_signout' => 1));
    }

    /**
     * @return mixed
     */
    public function getDataSignIn() {
        $date_now = Carbon::now();
        $current_date = $date_now->format('Y-m-d');

        if ($date_now->day >= DATE_START) {
            $month = $date_now->month;
            $date_start = $this->year($month) . '-' . $this->month($month) . '-' . DATE_START;
        } else {
            $month = $date_now->month - 1;
            $date_start = $this->year($month) . '-' . $this->month($month) . '-' . DATE_START;
        }


        $presensi = Presensi::whereRaw('user_id = ' . \Auth::user()->id . ' and signin != 0 and date(created_at) between "' . $date_start . '" and "' . $current_date . '"')
                ->get(['signin', 'signout', 'date'])
                ->toArray();
        return $presensi;
    }

    public function year($month) {
        if ($month > 0) {
            return date('Y');
        } else {
            return date('Y') - 1;
        }
    }

    public function month($month) {
        if ($month > 0) {
            return $month;
        } else {
            return 12;
        }
    }

    # get late all time in month
    /**
     * @return int|string
     */

    public function getLateConverted() {
        $dt = Carbon::now();
        if ($dt->day >= DATE_START) {
            $month = $dt->month - 1;
            $date = $this->year($month) . '-' . $this->month($month) . '-' . DATE_START;
        } else {
            $month = $dt->month - 1;
            $date = $this->year($month) . '-' . $this->month($month) . '-' . DATE_START;
        }
        $from = ($date < $dt) ? $date : $dt->format('Y-m-d');
        $to = ($date < $dt) ? $dt->format('Y-m-d') : $date;
        $presensi = Presensi::whereRaw('user_id = ' . \Auth::user()->id . ' and signin != 0 and date(created_at) between "' . $to . '" and "' . $from . '"')->get();
        $late = 0;
        foreach ($presensi as $lt) {
            $dt = Carbon::createFromTimeStamp($lt->signin);
            $start_office = explode(':', \Config::get('myapp.office_start'));
            $intime = Carbon::create($dt->year, $dt->month, $dt->day, $start_office[0], $start_office[1], $start_office[2])->addMinutes(\Config::get('myapp.max_late'));
             $lateInMinutes = $intime->diffInMinutes($dt, false);
            if($lateInMinutes > 0){
            $late +=  $lateInMinutes;
            }
        }
        $late = $this->convertToHoursMins($late);
        
        return ( $late != '') ? $late : 0;
    }

    /**
     * @return int|string
     */
    public function getOverTimeConverted() {
        $dt = Carbon::now();

        if ($dt->day >= DATE_START) {
            $month = $dt->month  - 1;
            $date = $this->year($month) . '-' . $this->month($month) . '-' . DATE_START;
        } else {
            $month = $dt->month - 1;
            $date = $this->year($month) . '-' . $this->month($month) . '-' . DATE_START;
        }

        $from = ($date < $dt) ? $date : $dt->format('Y-m-d');
        $to = ($date < $dt) ? $dt->format('Y-m-d') : $date;

        $presensi = Presensi::whereRaw('user_id = ' . \Auth::user()->id . ' and signin != 0 and date(created_at) between "' . $to . '" and "' . $from . '"')->get();
        $overtime = 0;

        foreach ($presensi as $lt) {
            $dt = Carbon::createFromTimeStamp($lt->signout);
            $start_office = explode(':', \Config::get('myapp.office_end'));
            $intime = Carbon::create($dt->year, $dt->month, $dt->day, $start_office[0], $start_office[1], $start_office[2])->addMinutes(\Config::get('myapp.min_overtime'));
            $overtime += ($intime->diffInMinutes($dt, false) > 0) ? $intime->diffInMinutes($dt, false) : 0;       
        }

        return ($this->convertToHoursMins($overtime) != '') ? $this->convertToHoursMins($overtime) : 0;
    }

    /**
     * @return int|string
     */
    public function getTotalWork() {
        $dt = Carbon::now();

        if ($dt->day >= DATE_START) {
            $month = $dt->month - 1;
            $date = $this->year($month) . '-' . $this->month($month) . '-' . DATE_START;
        } else {
            $month = $dt->month ;
            $date = $this->year($month) . '-' . $this->month($month) . '-' . DATE_START;
        }

        $from = ($date < $dt) ? $date : $dt->format('Y-m-d');
        $to = ($date < $dt) ? $dt->format('Y-m-d') : $date;

        $presensi = Presensi::whereRaw('user_id = ' . \Auth::user()->id . ' and signin != 0 and date(created_at) between "' . $to . '" and "' . $from . '"')->get();
        $total = '0';

        foreach ($presensi as $lt) {
            $signout = Carbon::createFromTimeStamp($lt->signout);
            $start_office = explode(':', \Config::get('myapp.office_end'));
            $dt = Carbon::create($signout->year, $signout->month, $signout->day, $start_office[0], $start_office[1], $start_office[2]);

            $intime = Carbon::createFromTimeStamp($lt->signin);
            $total += ($intime->diffInMinutes($dt, false) > 0) ? $this->convertToHoursMins($intime->diffInMinutes($dt, false)) : 0;
        }
        return $total;

    }

    /**
     * @param $id
     * @param $month
     * @param $year
     * @return int|string
     */
    public function getLateByMonth($id, $month, $year) {
        $month_start =  $month-1;        
        $from = $year . '-' . $month_start . '-' . DATE_START;
        
        if ($month == 12) {
            $to = $year + 1 . '-' . ($month) . '-' . DATE_END;
        } else {
            $to = $year . '-' . ($month) . '-' . DATE_END;
        }
        
        // $presensi = Presensi::whereRaw('user_id = '.$id.' and signin != 0 and month(created_at) = "'. $month.'" and year(created_at) = "'. $year.'"')->get();
        $presensi = Presensi::whereRaw('user_id = ' . $id . ' and signin != 0 and date(created_at) between "' . $from . '" and "' . $to . '"')->get();
        $late = 0;

        foreach ($presensi as $lt) {
            $dt = Carbon::createFromTimeStamp($lt->signin);
            $start_office = explode(':', \Config::get('myapp.office_start'));
            $intime = Carbon::create($dt->year, $dt->month, $dt->day, $start_office[0], $start_office[1], $start_office[2])->addMinutes(\Config::get('myapp.max_late'));
            $lateInMinutes = $intime->diffInMinutes($dt, false);
            if($lateInMinutes > 0){
            $late +=  $lateInMinutes;
            }
        }
        return ($this->convertToHoursMins($late) != '') ? $this->convertToHoursMins($late) : 0;
    }

    /**
     * @param $id
     * @param $month
     * @param $year
     * @return int|string
     */
    public function getOverTimeByMonth($id, $month, $year) {
        $month_start =  $month-1;
        $from = $year . '-' . $month_start . '-' . DATE_START;
        if ($month == 12) {
            $to = $year + 1 . '-' . ($month) . '-' . DATE_END;
        } else {
            $to = $year . '-' . ($month + 1) . '-' . DATE_END;
        }

        $presensi = Presensi::whereRaw('user_id = ' . $id . ' and signin != 0 and date(created_at) between "' . $from . '" and "' . $to . '"')->get();
        $overtime = 0;
        foreach ($presensi as $lt) {
            $dt = Carbon::createFromTimeStamp($lt->signout);
            $start_office = explode(':', \Config::get('myapp.office_end'));
            $intime = Carbon::create($dt->year, $dt->month, $dt->day, $start_office[0], $start_office[1], $start_office[2])->addMinutes(\Config::get('myapp.min_overtime'));
            $overtime += ($intime->diffInMinutes($dt, false) > 0) ? $intime->diffInMinutes($dt, false) : 0;
        }

        return ($this->convertToHoursMins($overtime) != '') ? $this->convertToHoursMins($overtime) : 0;
    }

    /**
     * @param $id
     * @param $month
     * @param $year
     * @return int|string
     */
    public function getTotalWorkByMonth($id, $month, $year) {
        $month_start = $month - 1;
        $presensi = Presensi::whereRaw('user_id = ' . $id . ' and signin != 0 and month(created_at) = "' . $month_start . '" and year(created_at) = "' . $year . '"')->get();
        $total = 0;

        foreach ($presensi as $lt) {
            $dt = Carbon::createFromTimeStamp($lt->signout);
            $start_office = explode(':', \Config::get('myapp.office_end'));
            $intime = Carbon::createFromTimeStamp($lt->signin);
            $total += ($intime->diffInMinutes($dt, false) > 0) ? $intime->diffInMinutes($dt, false) : 0;
        }

        return ($this->convertToHoursMins($total) != '') ? $this->convertToHoursMins($total) : 0;
    }

    /**
     * @param $time
     * @param string $format
     * @return string
     */
    public function convertToHoursMins($time, $format = '%d.%d') {
        settype($time, 'integer');
        if ($time < 1) {
            return;
        }
        $hours = floor($time / 60);
        $minutes = ($time % 60);
        return sprintf($format, $hours, $minutes);
    }

    /**
     * @param $date
     * @return string
     */
    public function getPresensiByDate($date) {
        $data = Presensi::where('date', '=', $date)->first();
        if ($data) {
            return "Ada";
        } else {
            return "tidak ada";
        }
    }

    /**
     * @param $id
     * @return \Illuminate\Support\Collection|static
     */
    public function find($id) {
        return Presensi::find($id);
    }

    public function update($id, $data) {
        $presensi = Presensi::find($id);

        $presensi->fill([
            'signin' => DateFormatter::toUnixDate($data['signin']),
            'signout' => DateFormatter::toUnixDate($data['signout']),
        ]);

        $presensi->save();

        return Presensi::find($id);
    }

    public function save($id, $data) {
        $create = Presensi::create([
                    'user_id' => $id,
                    'signin' => DateFormatter::toUnixDate($data['signin']),
                    'signout' => DateFormatter::toUnixDate($data['signout']),
                    'date' => DateFormatter::toUnixDate($data['signin']),
                    'session' => md5(Carbon::parse($data['signin'])->format('y-m-d')),
                    'signin_date' => $data['signin'],
                    'is_signout' => 1
        ]);

        return Presensi::find($create->id);
    }

    public function delete($id) {
        $data = Presensi::find($id);
        $data->delete();
    }

    public function isSignin() {
        $data = Presensi::where('user_id', '=', \Auth::user()->id)->where('signin_date', '=', date('Y-m-d'))->orderBy('id', 'desc')->first();
       return isset($data) && $data->is_signout != 1 ? $data->is_signout : 1;
    }

}
