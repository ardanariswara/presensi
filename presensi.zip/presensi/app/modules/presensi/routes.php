<?php

Route::group(array('namespace' => 'App\Modules\Presensi\Controllers\Member', 'before' =>['auth']), function(){

    Route::get('presensi', array('uses' => 'PresensiController@index', 'as' => 'member.presensi.index')) ;
    Route::get('presensi/{id}/signin', array('uses' => 'PresensiController@signIn', 'as' => 'member.presensi.signin')) ;
    Route::get('presensi/{id}/signout', array('uses' => 'PresensiController@signOut', 'as' => 'member.presensi.signout')) ;
    Route::get('presensi/{id}/noted', array('uses' => 'PresensiController@noted', 'as' => 'member.presensi.noted')) ;
    Route::post('presensi/{id}/noted', array('uses' => 'PresensiController@storeNoted', 'as' => 'member.presensi.noted')) ;

});

Route::group(array('prefix' => 'admin','namespace' => 'App\Modules\Presensi\Controllers\Admin', 'before' =>['auth', 'admin']), function(){

    Route::get('presensi', array('uses' => 'PresensiController@index', 'as' => 'admin.presensi.index')) ;
    Route::get('presensi/user/{id}', array('uses' => 'PresensiController@show', 'as' => 'admin.presensi.show')) ;
    Route::get('presensi/edit/{id}', array('uses' => 'PresensiController@edit', 'as' => 'admin.presensi.edit')) ;
    Route::get('presensi/new/{id}', array('uses' => 'PresensiController@newPresensi', 'as' => 'admin.presensi.new')) ;
    Route::post('presensi/edit/{id}', array('uses' => 'PresensiController@update', 'as' => 'admin.presensi.update')) ;
    Route::post('presensi/new/{id}', array('uses' => 'PresensiController@save', 'as' => 'admin.presensi.save')) ;
    Route::post('presensi/delete/{id}', array('uses' => 'PresensiController@delete', 'as' => 'admin.presensi.delete')) ;

});