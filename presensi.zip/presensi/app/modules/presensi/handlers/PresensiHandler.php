<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 06/11/14
 * Time: 15:49
 */

namespace App\Modules\Presensi\Handlers;

use App\Modules\Presensi\Models\Presensi;
class PresensiHandler {

    /**
     * @return bool
     */
    public function whenUserHasSignIn()
    {
        $presensi = Presensi::where('user_id', '=', \Auth::user()->id)
            ->where('signin', '!=', 0)
            ->where('session', '=', md5(date('y-m-d')))
            ->first();
//        return $presensi;
        if(isset($presensi))
        {
//            return \Redirect::intended('member/presensi')->with('error', 'Anda Telah Presensi Hari Ini');
            return false;
        }
        return true;
    }

    /**
     * @return bool
     */
    public function whenUserHasSignOut()
    {
        $presensi = Presensi::where('user_id', '=', \Auth::user()->id)
            ->where('signout', '!=', 0)
            ->where('session', '=', md5(date('y-m-d')))
            ->first();
        if(isset($presensi))
        {
//            return \Redirect::intended('member/presensi')->with('error', 'Anda Telah Presensi Hari Ini');
            return false;
        }
        return true;
    }

} 