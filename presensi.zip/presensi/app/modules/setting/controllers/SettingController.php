<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 06/11/14
 * Time: 19:36
 */

namespace App\Modules\Setting\Controllers;


use Illuminate\Support\Facades\View;
use DateTimeZone;
use App\Modules\Attributes\Repositories\AttributeRepository;

class SettingController extends \BaseController{

    protected $attribute;

    function __construct(AttributeRepository $attribute)
    {
        $this->attribute = $attribute;
    }

    public function index()
    {
        $earningAttribute = $this->attribute->earningAttributes();

        $deductionAttribute = $this->attribute->deductionAttributes();

        $tzlist = DateTimeZone::listIdentifiers(DateTimeZone::ALL);

        return View::make('setting::index', compact('tzlist', 'earningAttribute', 'deductionAttribute'));
    }

} 