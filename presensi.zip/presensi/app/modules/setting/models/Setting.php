<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 06/11/14
 * Time: 17:08
 */

namespace App\Modules\Setting\Models;

use Illuminate\Database\Eloquent\Model;

class Setting extends Model{

    protected $table = 'settings';

    protected $fillable = ['key', 'value'];

} 