<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 06/11/14
 * Time: 17:10
 */

namespace App\Modules\Setting;


use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\ServiceProvider;

class SettingServiceProvider extends ServiceProvider {

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {

    }

    public function boot()
    {
        App::before(function($request){

            $settings = App::make('App\Modules\Setting\Repositories\SettingRepositories');

            if ($settings->setAll())
            {
                // Set the environment timezone to the application specific timezone, if available, otherwise UTC
                date_default_timezone_set((Config::get('myapp.timezone') ?: Config::get('app.timezone')));

            }

        });
    }
}