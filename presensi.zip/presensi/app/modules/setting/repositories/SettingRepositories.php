<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 06/11/14
 * Time: 17:12
 */

namespace App\Modules\Setting\Repositories;

use App\Modules\Setting\Models\Setting;

class SettingRepositories {

    public function setAll()
    {
        try
        {
            $settings = Setting::all();

            foreach ($settings as $setting)
            {
                \Config::set('myapp.' . $setting->key, $setting->value);
            }

            return true;

        }
        catch (\Illuminate\Database\QueryException $e)
        {
            return false;
        }
        catch (\PDOException $e)
        {
            return false;
        }
    }

} 