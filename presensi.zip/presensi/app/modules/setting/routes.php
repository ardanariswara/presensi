<?php

Route::group(['prefix' => 'admin', 'before' => ['auth', 'admin'], 'namespace' => 'App\Modules\Setting\Controllers'], function(){

    Route::get('settings', ['uses' => 'SettingController@index', 'as' => 'settings.index']);

});