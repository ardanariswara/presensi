@extends('layouts.default')

@section('content')

<div class="container">

    <div class="row" >
        <div  class="col-sm-12">
            <h3>Pengaturan Aplikasi</h3>
            <hr/>
            <div class="col-xs-12"> <!-- required for floating -->
                <!-- Nav tabs -->
                <ul class="nav nav-tabs tabs-lefts">
                    <li class="active"><a href="#general" data-toggle="tab">General</a></li>
                    <li><a href="#company" data-toggle="tab">Perusahaan</a></li>
                    <li><a href="#attribute" data-toggle="tab">Attribute Gaji Karyawan</a></li>

                </ul>
            </div>
            <div class="clearfix"></div>
            <br>
            <div class="col-xs-12">
                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane active" id="general">
                        <div class="form-horizontal" role="form">
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Mulai Jam Kerja</label>
                                <div class="col-sm-2">
                                    <input type="text" class="form-control" id="office_start" name="office_start" value="{{ Config::get('myapp.office_start') }}" placeholder="08:00:00">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputEmail3" class="col-sm-2 control-label">Akhir Jam Kerja</label>
                                <div class="col-sm-2">
                                    <input type="text" class="form-control" id="office_start" name="office_end" value="{{ Config::get('myapp.office_end') }}" placeholder="08:00:00">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputPassword3" class="col-sm-2 control-label">Batas Keterlambatan (menit)</label>
                                <div class="col-sm-2">
                                    <input type="text" class="form-control" id="max_late" name="max_late" value="{{ Config::get('myapp.max_late') }}" placeholder="30">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputPassword3" class="col-sm-2 control-label">Minimal Lembur (menit)</label>
                                <div class="col-sm-2">
                                    <input type="text" class="form-control" id="min_overtime" name="{{ Config::get('myapp.min_overtime') }}" value="30" placeholder="30">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="inputPassword3" class="col-sm-2 control-label">Zona Waktu</label>
                                <div class="col-sm-4">
                                    <select class="form-control" name="timezone" id="timezone">
                                        @foreach($tzlist as $tz)
                                        <option value="{{ $tz }}" {{ ($tz == Config::get('myapp.timezone')) ? 'selected' : '' }}>{{ $tz }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="button" class="btn btn-primary">Simpan</button>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane" id="company">
                        ----
                    </div>

                    <div class="tab-pane" id="attribute">
                        <div class="col-md-12">
                            <div class="form-group">
                                <button class="btn btn-primary" data-toggle="modal" data-target="#modal-attribute">tambah baru</button>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h3>Attribute Penambahan Gaji</h3>
                            <table class="table table-bordered" id="earning-table">
                                <tr>
                                    <th>Nama</th>
                                    <th>Keterangan</th>
                                    <th>Nilai</th>
                                    <th></th>
                                </tr>
                                @foreach($earningAttribute as $key => $earning)
                                <tr id="item-{{$earning->id}}">
                                    <td id="name">{{ $earning->name }}</td>
                                    <td id="description">{{ $earning->description }}</td>
                                    <td id="value">{{ $earning->value }}</td>
                                    <td>
                                        <a href="javascript:;" class="btn btn-primary btn-sm" id="edit-attribute" data-url="{{ route('attribute.edit', [$earning->id]) }}" data-id="{{ $earning->id }}"><i class="glyphicon glyphicon-edit"></i> </a>
                                        <a href="javascript:;" class="btn btn-danger btn-sm" id="delete-attribute" data-url="{{ route('attribute.delete', [$earning->id]) }}" data-id="{{ $earning->id }}"><i class="glyphicon glyphicon-trash"></i> </a>
                                    </td>
                                </tr>
                                @endforeach
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h3>Attribute Pengurangan Gaji</h3>
                            <table class="table table-bordered" id="deduction-table">
                                <tr>

                                    <th>Nama</th>
                                    <th>Keterangan</th>
                                    <th>Nilai</th>
                                    <th></th>
                                </tr>
                                @foreach($deductionAttribute as $key => $deduction)
                                <tr id="{{ $deduction->id }}">

                                    <td id="name">{{ $deduction->name }}</td>
                                    <td id="description">{{ $deduction->description }}</td>
                                    <td id="value">{{ $deduction->value }}</td>
                                    <td>
                                        <a href="javascript:;" class="btn btn-primary btn-sm" id="edit-attribute" data-url="{{ route('attribute.edit', [$deduction->id]) }}" data-id="{{ $deduction->id }}"><i class="glyphicon glyphicon-edit"></i> </a>
                                        <a href="javascript:;" class="btn btn-danger btn-sm" id="delete-attribute" data-url="{{ route('attribute.delete', [$deduction->id]) }}" data-id="{{ $deduction->id }}"><i class="glyphicon glyphicon-trash"></i> </a>
                                    </td>
                                </tr>
                                @endforeach
                            </table>
                        </div>

                    </div>


                </div>

            </div>

            <div class="clearfix"></div>


        </div>

    </div>

</div>
<div class="modal fade" id="modal-attribute" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="myModalLabel">Modal title</h4>
            </div>
            <div class="modal-body">
                {{ Form::open(['route' => 'attribute.store', 'id' => 'attribute-form']) }}
                    <div class="form-group">
                        <label for="exampleInputEmail1">Nama Attribute</label>
                        <input type="text" name="name" id="name" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Keterangan</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="exampleInputPassword1">Nilai</label>
                        <input type="text" name="value" id="value" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>Type</label>
                        <select class="form-control" name="type" id="type">
                            <option value="earning">Penambah</option>
                            <option value="deduction">Pengurang</option>
                        </select>
                    </div>
                    <button type="button" id="save-attribute" class="btn btn-default">Submit</button>
                {{ Form::close() }}
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modal-edit-attribute" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title" id="myModalLabel">Modal title</h4>
            </div>
            <div class="modal-body">
                {{ Form::open(['id' => 'attribute-edit-form']) }}
                <div class="form-group">
                    <label for="exampleInputEmail1">Nama Attribute</label>
                    <input type="text" name="name" id="name" class="form-control">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Keterangan</label>
                    <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Nilai</label>
                    <input type="text" name="value" id="value" class="form-control">
                </div>
                <div class="form-group">
                    <label>Type</label>
                    <select class="form-control" name="type" id="type">
                        <option value="earning">Penambah</option>
                        <option value="deduction">Pengurang</option>
                    </select>
                </div>
                <button type="button" id="update-attribute" class="btn btn-default">Submit</button>
                {{ Form::close() }}
            </div>
        </div>
    </div>
</div>


@stop

@section('scripts')
<script>
    $(function(){
        $('#save-attribute').on('click', function(){
            var form = $('#attribute-form').serialize();
            var url = $('#attribute-form').attr('action');
            $.post(url, form)
                .done(function(data){
//                    console.log(data);
//                    var url_edit = "{{route('attribute.edit', "+ data.id +")}}";
                    var url_edit = "{{ Request::root() }}/admin/attribute/"+ data.id;
                    var url_delete = "{{ Request::root() }}/admin/attribute/delete/"+ data.id;
                    var table = '<tr id="item-'+data.id+'"><td id="name">'+ data.name +'</td><td id="description">'+ data.description +'</td><td id="value">'+ data.value +'</td><td><a href="javascript:;" id="edit-attribute" data-url="'+ url_edit +'" data-id="'+ data.id +'" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-edit"></i> </a> <a href="javascript:;" id="delete-attribute" data-url="'+ url_delete +'" data-id="'+ data.id +'" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-trash"></i> </a></td></tr>';
                    if(data.type == 'earning'){
                        $('#earning-table').append(table);
                    }else{
                        $('#deduction-table').append(table);
                    }
                    $('#modal-attribute').modal('hide');
                    $('#attribute-form')[0].reset();
                })
        })

        $('table').on('click', '#edit-attribute', function()
        {
            var url = $(this).data('url');
            $('#modal-edit-attribute').modal('show');
//            console.log(url)
            $.get(url)
                .done(function(data){
                    $('#attribute-edit-form').attr('action', url)
                    $('#attribute-edit-form #name').val(data.name)
                    $('#attribute-edit-form #description').val(data.description)
                    $('#attribute-edit-form #value').val(data.value)
                    $('#attribute-edit-form #type').val(data.type)

                })
        });

        $('#update-attribute').on('click', function(){
            var form = $('#attribute-edit-form').serialize();
            var url = $('#attribute-edit-form').attr('action');
            $.post(url, form)
                .done(function(data){
                    var $this = $('table tr#item-'+ data.id);
//                    console.log(data);
                    $.each(data, function(i, v){
//                        console.log($this.find('#'+i));
                        $this.find('#'+i).text(v);
                    })
                    $('#modal-edit-attribute').modal('hide');
                })
        })

        $('table').on('click', '#delete-attribute', function(){
            var $this = $(this);
//            $this.parent().parent().remove();
            var url = $(this).data('url');
//            console.log(url)
            if(confirm('hapus data')){
                $.get(url)
                    .done(function(data){
                        $this.parent().parent().remove();
                    })
            }


        });
    })
</script>
@stop