<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 07/11/14
 * Time: 17:41
 */

namespace App\Modules\Attributes\Models;


use Illuminate\Database\Eloquent\Model;

class AttributeValue extends Model {

    protected $table = 'attribute_values';

    protected $fillable = ['attribute_id', 'payslip_id', 'value'];

    public function attribute()
    {
        return $this->belongsTo('App\Modules\Attributes\Models\Attribute');
    }

    /*public function payslip()
    {
        return $this->belongsTo('PresensiApp\PaySlip');
    }*/

} 