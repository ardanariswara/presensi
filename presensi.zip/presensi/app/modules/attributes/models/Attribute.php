<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 07/11/14
 * Time: 17:06
 */

namespace App\Modules\Attributes\Models;


use Illuminate\Database\Eloquent\Model;

class Attribute extends Model {

    protected $table = 'attributes';

    protected $fillable = ['name', 'description', 'type', 'value'];

    public function values()
    {
        return $this->hasMany('App\Modules\Attributes\Models\AttributeValue');
    }

} 