<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 10/11/14
 * Time: 15:11
 */

namespace App\Modules\Attributes\Repositories;

use App\Modules\Attributes\Models\AttributeValue;

class AttributeValueRepository {

    public function all() {

    }

    public function delete($id) {

    }

    public function find($id) {

    }

    public function store($data) {

        return AttributeValue::create($data);

    }

    public function update($id, $data) {
        $attr = AttributeValue::find($id);
        $attr->fill($data);
        $attr->save();
    }
    
    public function deleteByPaySlipId($payslip_id) {
        $attr = AttributeValue::where('payslip_id', '=', $payslip_id)->delete();
        // $attr->destroy();
    }

} 