<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 07/11/14
 * Time: 19:16
 */

namespace App\Modules\Attributes\Repositories;

use App\Modules\Attributes\Models\Attribute;

class AttributeRepository {

    public function all()
    {
        return Attribute::all();
    }

    public function create($data)
    {
        return Attribute::create([
            'name' => $data['name'],
            'description' => $data['description'],
            'type' => $data['type'],
            'value' => $data['value']
        ]);
    }

    public function update($id, $data)
    {
        $attribute = Attribute::find($id);

        $attribute->fill([
            'name' => $data['name'],
            'description' => $data['description'],
            'type' => $data['type'],
            'value' => $data['value']
        ]);

        $attribute->save();
    }

    public function delete($id)
    {
        return Attribute::destroy([$id]);
    }

    public function earningAttributes()
    {
        return Attribute::where('type', '=', 'earning')->get();
    }

    public function deductionAttributes()
    {
        return Attribute::where('type', '=', 'deduction')->get();
    }

    public function find($id)
    {
        return Attribute::find($id);
    }

} 