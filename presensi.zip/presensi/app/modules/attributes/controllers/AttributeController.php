<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 07/11/14
 * Time: 19:44
 */

namespace App\Modules\Attributes\Controllers;


use Barryvdh\Debugbar\Controllers\BaseController;
use App\Modules\Attributes\Repositories\AttributeRepository;
use Illuminate\Support\Facades\Input;

class AttributeController extends BaseController {

    protected $attribute;

    function __construct(AttributeRepository $attribute)
    {
        $this->attribute = $attribute;
    }

    public function create()
    {
        return $this->attribute->create(Input::all());
    }

    public function edit($id)
    {
        return $this->attribute->find($id);
    }

    public function update($id)
    {
        $this->attribute->update($id, Input::all());

        return $this->attribute->find($id);
    }

    public function destroy($id)
    {
        return $this->attribute->delete($id);
    }



} 