<?php

Route::group(['prefix' => 'admin', 'before' => ['auth', 'admin'], 'namespace' => 'App\Modules\Attributes\Controllers'], function(){
    Route::post('attribute', ['uses' => 'AttributeController@create', 'as' => 'attribute.store']);
    Route::get('attribute/{id}', ['uses' => 'AttributeController@edit', 'as' => 'attribute.edit']);
    Route::get('attribute/delete/{id}', ['uses' => 'AttributeController@destroy', 'as' => 'attribute.delete']);
    Route::post('attribute/{id}', ['uses' => 'AttributeController@update', 'as' => 'attribute.update']);
});