<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 02/12/14
 * Time: 15:57
 */

namespace App\Modules\User\Classes;


class InputFormatter {

    public static function bankFormatter($bankName, $an, $norek)
    {
        if(empty($bankName)){
            return '';
        }
        foreach( $bankName as $key => $bn){
            $bank[$key]['bank'] = $bn;
            $bank[$key]['an'] = $an[$key];
            $bank[$key]['norek'] = $norek[$key];
        }

        return serialize($bank);
    }

    public static function phoneFormatter($phones){
        if(empty($phones)){
            return '';
        }
        return serialize($phones);
    }

} 