<?php

//use Zizaco\Entrust\Entrust;

Route::group(['prefix' => 'admin', 'before' => ['auth', 'admin'], 'namespace' => 'App\Modules\User\Controllers'], function(){
    # User
    Route::resource('user', 'UserController');
    Route::get('user/{id}/delete', ['uses' => 'UserController@destroy', 'as' => 'user.destroy']);

    # Role
    Route::resource('role', 'RoleController');
    Route::get('role/{id}/delete', ['uses' => 'RoleController@destroy', 'as' => 'role.destroy']);
    
    Route::get('user/export/{type}', ['uses' => 'UserController@export', 'as' => 'user.export']);

});

Route::group(['before' => ['auth'], 'namespace' => 'App\Modules\User\Controllers'], function(){
    Route::get('profile', ['uses' => 'UserController@profile', 'as' => 'profile']);
    Route::post('profile/{id}', ['uses' => 'UserController@updateProfile', 'as' => 'profile.update']);
    Route::post('profile/update-password/{id}', ['uses' => 'UserController@updatePassword', 'as' => 'profile.update.password']);
});