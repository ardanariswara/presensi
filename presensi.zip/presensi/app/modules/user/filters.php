<?php
//App::register('Zizaco\Entrust\EntrustServiceProvider');
//Entrust::routeNeedsRole( 'admin*', array('Admin'), Redirect::to('/') );