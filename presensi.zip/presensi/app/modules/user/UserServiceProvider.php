<?php
/**
 * Created by PhpStorm.
 * User: ardiansyah
 * Date: 11/5/14
 * Time: 2:50 AM
 */

namespace App\Modules\User;


use Illuminate\Support\ServiceProvider;

class UserServiceProvider extends ServiceProvider {

    /*public function boot()
    {
        require __DIR__ . '/filters.php';
    }*/

    /**
     * Register the service provider.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(
            'App\Modules\User\Repositories\RoleRepository',
            'App\Modules\User\Repositories\UserRepository'
        );
    }
}