<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 07/11/14
 * Time: 12:51
 */

namespace App\Modules\User\Presenters;


use Carbon\Carbon;
use Laracasts\Presenter\Presenter;

class UserPresenter extends Presenter {

    public function setStatus()
    {
        switch($this->status){
            case 'TK': return "Belum Menikah"; break;
            case 'K': return "Menikah"; break;
        }
    }

    public function setGender()
    {
        switch($this->gender){
            case 'L': return "Laki-laki"; break;
            case 'P': return "Perempuan"; break;
        }
    }

    public function setBirthDay()
    {
        return Carbon::parse($this->birthday)->format('j F Y');
    }

    public function setHireDate()
    {
        return Carbon::parse($this->hiredate)->format('j F Y');
    }

    public function setPrivateEmail()
    {   
        if(isset($this->private_email)){
            $emails = $this->private_email;
            $explode = unserialize($emails);
            $email = ''.PHP_EOL;
            foreach($explode as $ex){
                $email .= $ex.'<br>';
            }

            return $email;
        }else{
            return '';
        }
        
    }


    public function setPhone()
    {
        if( isset($this->phone)){
            $explode = unserialize($this->phone);
            $phone = ''.PHP_EOL;
            foreach($explode as $ex){
                $phone .= $ex.'<br>';
            }

            return $phone;
        }else{
            return '';
        }
        
    }

    public function setInputPrivateEmail()
    {
        return unserialize($this->private_email);
    }

    public function setInputPhone()
    {
        return unserialize($this->phone);
    }


} 