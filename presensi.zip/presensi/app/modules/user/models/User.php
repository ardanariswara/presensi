<?php

/**
 * Created by PhpStorm.
 * User: ardiansyah
 * Date: 11/5/14
 * Time: 2:13 AM
 */

namespace App\Modules\User\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Hash;
use Laracasts\Presenter\PresentableTrait;
use Zizaco\Entrust\HasRole;

class User extends Model {

    use HasRole,
        PresentableTrait;

    protected $table = 'users';
    protected $fillable = [
        'username',
        'email',
        'password',
        'nip',
        'fullname',
        'jabatan',
        'alamat',
        'status',
        'tanggungan',
        'foto',
        'gender',
        'birthday_city',
        'birthday',
        'hiredate',
        'phone',
        'private_email',
        'gaji_pokok',
        'bank_account',
        'tunjangan'
    ];
    protected $presenter = 'App\Modules\User\Presenters\UserPresenter';

    /* public function setPasswordAttribute($password)
      {
      $this->attributes['password'] = Hash::make($password);
      } */

    /**
     * Save roles inputted from multiselect
     * @param $inputRoles
     */
    public function saveRoles($inputRoles) {
        if (!empty($inputRoles)) {
            $this->roles()->sync($inputRoles);
        } else {
            $this->roles()->detach();
        }
    }

    /**
     * Returns user's current role ids only.
     * @return array|bool
     */
    public function currentRoleIds() {
        $roles = $this->roles;
        $roleIds = false;
        if (!empty($roles)) {
            $roleIds = array();
            foreach ($roles as &$role) {
                $roleIds[] = $role->id;
            }
        }
        return $roleIds;
    }

    public function presensi() {
        return $this->hasMany('App\Modules\Presensi\Models\Presensi');
    }

    public function scopeJhtPerusahaan() {
        return $this->attributes['gaji_pokok'] * (3.7 / 100);
    }

    public function scopeJhtKaryawan() {
        return $this->attributes['gaji_pokok'] * (2 / 100);
    }

    public function scopeJkkPerusahaan() {
        return $this->attributes['gaji_pokok'] * (0.24 / 100);
    }

    public function scopeJkmPerusahaan() {
        return $this->attributes['gaji_pokok'] * (0.3 / 100);
    }

    public function scopeKshtPerusahaan() {
        return $this->attributes['gaji_pokok'] * (4 / 100);
    } 

    public function scopeKshtKaryawan() {
        return $this->attributes['gaji_pokok'] * (1 / 100);
    }
  
  public function scopePensiunKaryawan() {
        return $this->attributes['gaji_pokok'] * (1/ 100);
    }
  
   public function scopePensiunPerusahaan() {
        return $this->attributes['gaji_pokok'] * (2/ 100);
    }

//    public function scop
}
