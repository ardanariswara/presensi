@extends('layouts.default')

@section('content')

<div class="col-xs-12 col-sm-12">

    <div class="pull-right">
        <a href="{{ route('admin.role.create') }}" class="btn btn-success">Buat Baru</a>
    </div>
    <h3>Roles</h3>

    <table class="table table-bordered">
        <thead>
        <tr>
            <th>#</th>
            <th class="text-center">Nama</th>
            <th></th>
        </tr>
        </thead>
        <tbody>
        @foreach($roles as $key => $role)
        <tr>
            <td>{{$key+1}}</td>
            <td class="text-center">{{$role->name}}</td>
            <td class="text-center">
                <a href="{{ route('admin.role.edit', [$role->id]) }}" class="btn btn-default">Edit</a>
                <a href="{{ route('role.destroy', [$role->id]) }}" class="btn btn-danger">Delete</a>
            </td>
        </tr>
        @endforeach
        </tbody>
    </table>

</div><!--/.col-xs-12.col-sm-9-->

@stop