@extends('layouts.default')

@section('content')

<div class="col-xs-12 col-sm-12">
    @if($editMode == false)
    {{ Form::open(['route' => 'admin.role.store', 'class' => 'form-horizontal']) }}
    @else
    {{ Form::model($role, ['route' => ['admin.role.update', $role->id], 'class' => 'form-horizontal', 'method' => 'PATCH']) }}
    @endif
        <div class="form-group">
            <label for="inputEmail3" class="col-sm-2 control-label">Nama Role</label>
            <div class="col-sm-5">
                {{ Form::text('name', null, ['class' => 'form-control']) }}
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-default">Simpan</button>
            </div>
        </div>
    {{ Form::close() }}

</div><!--/.col-xs-12.col-sm-9-->

@stop