@extends('layouts.default')

@section('content')

<div class="col-xs-12 col-sm-12">


    @if($editMode == false)
    <h3>Tambah Pengguna Baru</h3>
    <hr>
    {{ Form::open(['route' => 'admin.user.store', 'class' => 'form-horizontal']) }}
    @else
    <h3>Edit Pengguna {{ $user->fullname }}</h3>
    <hr>
    {{ Form::model($user, ['route' => ['admin.user.update', $user->id], 'class' => 'form-horizontal', 'method' => 'PATCH']) }}
    @endif

    <div class="form-group">
        <label class="col-sm-2 control-label">NIP</label>
        <div class="col-sm-5">
            @if($editMode == false)
            {{ Form::text('nip', $nik, ['class' => 'form-control']) }}
            @else
            {{ Form::text('nip', null, ['class' => 'form-control']) }}
            @endif
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Nama</label>
        <div class="col-sm-5">
            {{ Form::text('fullname', null, ['class' => 'form-control']) }}
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Email Perusahaan</label>
        <div class="col-sm-5">
            {{ Form::email('email', null, ['class' => 'form-control']) }}
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Jabatan</label>
        <div class="col-sm-5">
            {{ Form::text('jabatan', null, ['class' => 'form-control']) }}
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Alamat</label>
        <div class="col-sm-5">
            {{ Form::textarea('alamat', null, ['class' => 'form-control']) }}
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Telepon</label>
        <div class="col-sm-5">
            <span class="phone-wrap" style="margin-bottom: 5px">
            @if(!empty($user->phone))
                @foreach($user->present()->setInputPhone as $phone)
                <div>
                    <input type="text" class="custom-form-control" name="phone[]" id="private_email" value="{{ $phone }}" style="width: 255px; margin-bottom: 5px" disabled>
                </div>
                @endforeach
            @endif

            </span>
        </div>
    </div>

    <div class="form-group">
        <label class="col-sm-2 control-label">Email Pribadi</label>
        <div class="col-sm-5">
            <span class="email-wrap" style="margin-bottom: 5px">
            @if(!empty($user->private_email))
                @foreach($user->present()->setInputPrivateEmail as $email)
                <div>
                    <input type="text" class="custom-form-control" name="private_email[]" id="private_email" value="{{ $email }}" style="width: 300px; margin-bottom: 5px">
                </div>
                @endforeach
            @endif

            </span>
        </div>
    </div>
    @if($editMode == true)
    <div class="form-group">
        <label class="col-sm-2 control-label">Akun Bank</label>
        <div class="col-sm-10">
            <span class="bank-wrap">
            @if(!empty($user->bank_account))
            @foreach(unserialize($user->bank_account) as $bank)
            <div>
                <input type="text" class="custom-form-control" name="bank-name[]" value="{{ $bank['bank'] }}" placeholder="Nama Bank" style="margin-bottom: 5px;" disabled>
                <input type="text" class="custom-form-control" name="an[]" value="{{ $bank['an'] }}" placeholder="Nama Akun" style="margin-bottom: 5px;" disabled>
                <input type="text" class="custom-form-control" name="norek[]" value="{{ $bank['norek'] }}" placeholder="Nomer Rekening" style="margin-bottom: 5px;" disabled>
            </div>
            @endforeach
            @endif
            </span>
        </div>
    </div>

    @endif
    <div class="form-group">
        <label class="col-sm-2 control-label">Status</label>
        <div class="col-sm-5">
            {{ Form::select('status', array('TK' => 'Belum Menikah', 'K' => 'Menikah'), null, ['class' => 'form-control']) }}
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Gender</label>
        <div class="col-sm-5">
            {{ Form::select('gender', array('L' => 'Laki-Laki', 'P' => 'Perempuan'), null, ['class' => 'form-control']) }}
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Tanggungan</label>
        <div class="col-sm-1">
            {{ Form::number('tanggungan', null, ['class' => 'form-control','min' => 0]) }}
        </div>
    </div>

    <div class="form-group">
        <label class="col-sm-2 control-label">Tanggal Masuk</label>
        <div class="col-sm-5">
            {{ Form::text('hiredate', null, ['class' => 'form-control','id' => 'hiredate', 'data-date-format' => 'YYYY-MM-DD']) }}
        </div>
    </div>

    <div class="form-group">
        <label class="col-sm-2 control-label">Kota Lahir</label>
        <div class="col-sm-5">
            {{ Form::text('birthday_city', null, ['class' => 'form-control','id' => 'birthday_city']) }}
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Tanggal Lahir</label>
        <div class="col-sm-5">
            {{ Form::text('birthday', null, ['class' => 'form-control','id' => 'birthday', 'data-date-format' => 'YYYY-MM-DD']) }}
        </div>
    </div>

    <div class="form-group">
        <label class="col-sm-2 control-label">Gaji Pokok</label>
        <div class="col-sm-5">
            {{ Form::text('gaji_pokok', null, ['class' => 'form-control','id' => 'gaji_pokok']) }}
        </div>
    </div>
    
      <div class="form-group">
        <label class="col-sm-2 control-label">Tunjangan</label>
        <div class="col-sm-5">
            {{ Form::checkbox('tunjangan', 1, null, ['class' => 'form-contro','id' => 'tunjangan'])}}
        </div>
    </div>


                                
    <div class="form-group">
        <label class="col-sm-2 control-label">Role</label>
        <div class="col-sm-5">
            {{-- Form::select('role[]', $roles, null, ['class' => 'form-control']) --}}
            <select class="form-control" name="roles[]" id="roles[]" multiple>
                @foreach ($roles as $role)
                @if ($editMode == false)
                <option value="{{{ $role->id }}}"{{{ ( in_array($role->id, $selectedRoles) ? ' selected="selected"' : '') }}}>{{{ $role->name }}}</option>
                @else
                <option value="{{{ $role->id }}}"{{{ ( array_search($role->id, $userRoleId) !== false && array_search($role->id, $userRoleId) >= 0 ? ' selected="selected"' : '') }}}>{{{ $role->name }}}</option>
                @endif
                @endforeach
            </select>
        </div>
    </div>

    <div class="form-group">
        <label class="col-sm-2 control-label">Foto</label>
        <div class="col-sm-5">
            <input type="file" name="foto" class="form-control">
        </div>
    </div>
    @if ($editMode == false)
    <div class="form-group">
        <label class="col-sm-2 control-label">Password</label>
        <div class="col-sm-5">
            {{ Form::password('password', ['class' => 'form-control']) }}
        </div>
    </div>
    <div class="form-group">
        <label class="col-sm-2 control-label">Confirm Password</label>
        <div class="col-sm-5">
            {{ Form::password('password_confirmation', ['class' => 'form-control']) }}
        </div>
    </div>
    @else
    @endif
    <div class="form-group">
        <label class="col-sm-2 control-label">&nbsp;</label>
        <div class="col-sm-5">
            <button type="submit" class="btn btn-success">Simpan</button>
        </div>
    </div>
    {{ Form::close() }}

</div><!--/.col-xs-12.col-sm-9-->

@stop

@section('scripts')
<script>
    $(document).ready(function(){
        $('#birthday, #hiredate').datetimepicker();
    })

</script>
@stop