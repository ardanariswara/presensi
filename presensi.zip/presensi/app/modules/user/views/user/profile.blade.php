@extends('layouts.default')

@section('content')

<div class="col-md-12">
    <h3>{{ $user->fullname }}</h3>

    <div class="tabbable-panel">
        <div class="tabbable-line">
            <ul class="nav nav-tabs ">
                <li class="active">
                    <a href="#profile" data-toggle="tab">Profil</a>
                </li>
                <li>
                    <a href="#setting" data-toggle="tab">Setting </a>
                </li>
                <li>
                    <a href="#password" data-toggle="tab">Rubah Password </a>
                </li>
            </ul>
            <div class="tab-content">
                <div class="tab-pane active" id="profile">
                    <div class="row">
                        <div class="col-md-3 col-lg-3 " align="center">
                            @if($user->foto)
                            <img id="preview" src="{{ asset('uploads/user/thumbnail/'.$user->foto) }}" class="img-rounded">
                            @else
                            <img  src="https://lh5.googleusercontent.com/-b0-k99FZlyE/AAAAAAAAAAI/AAAAAAAAAAA/eu7opA4byxI/photo.jpg?sz=200" class="img-rounded">
                            @endif
                        </div>

                        <div class=" col-md-9 col-lg-9 ">
                            <table class="table table-user-information">
                                <tbody>
                                <tr>
                                    <td>NIP:</td>
                                    <td>{{ $user->nip }}</td>
                                </tr>
                                <tr>
                                    <td>Email Company</td>
                                    <td>{{$user->email}}</td>
                                </tr>
                                <tr>
                                    <td>Jabatan:</td>
                                    <td>{{ $user->jabatan }}</td>
                                </tr>
                                <tr>
                                    <td>Gender</td>
                                    <td>{{ $user->present()->setGender }}</td>
                                </tr>
                                <tr>
                                    <td>Alamat</td>
                                    <td>{{$user->alamat}}</td>
                                </tr>
                                <tr>
                                    <td>Email Pribadi</td>
                                    <td>{{$user->present()->setPrivateEmail}}</td>
                                </tr>

                                <tr>
                                    <td>Phone Number</td>
                                    <td>{{ $user->present()->setPhone }}</td>
                                </tr>
                                <tr>
                                    <td>Akun Bank</td>
                                    <td>
                                        @if(!empty($user->bank_account))
                                        @foreach(unserialize($user->bank_account) as $bank)
                                        <table class="table">
                                            <tr>
                                                <th> Bank</th>
                                                <td>{{$bank['bank']}} </td>
                                            </tr>
                                            <tr>
                                                <th> A/N</th>
                                                <td>{{$bank['an']}} </td>
                                            </tr>
                                            <tr>
                                                <th> No. Rekening</th>
                                                <td>{{$bank['norek']}} </td>
                                            </tr>
                                        </table>
                                        @endforeach
                                        @endif
                                    </td>
                                </tr>
                                <tr>
                                    <td>Status:</td>
                                    <td>{{ $user->present()->setStatus }}</td>
                                </tr>
                                <tr>
                                    <td>Tanggungan:</td>
                                    <td>{{ $user->tanggungan }}</td>
                                </tr>
                                <tr>
                                    <td>Hire date:</td>
                                    <td>{{ $user->present()->setHireDate }}</td>
                                </tr>
                                <tr>
                                    <td>Date of Birth</td>
                                    <td>{{ $user->present()->setBirthDay }}</td>
                                </tr>

                                <tr>
                                    <td>Gaji</td>
                                    <td>{{ $user->gaji_pokok }}</td>
                                </tr>
                                
                                <tr>
                                    <td>Tunjangan</td>
                                    <td>{{  $user->tunjangan==1 ? 'Aktif' : 'Non-Aktif'  }}</td>
                                </tr>

                                <tr>
                                </tbody>
                            </table>
                        </div> 
                    </div>
                </div>
                <div class="tab-pane" id="setting">
                    <div class="tab-pane active" id="profile">

                            {{ Form::open(['route' => ['profile.update', Auth::user()->id], 'method' => 'POST', 'files' => true]) }}
                        <div class="row">
                            <div class="col-md-3 col-lg-3 " align="center">
                                @if($user->foto)
                                <img id="preview" src="{{ asset('uploads/user/thumbnail/'.$user->foto) }}" class="img-rounded">
                                @else
                                <img id="preview" src="https://lh5.googleusercontent.com/-b0-k99FZlyE/AAAAAAAAAAI/AAAAAAAAAAA/eu7opA4byxI/photo.jpg?sz=200" class="img-rounded">
                                @endif
                                <div class="clearfix"></div>
                                <br>
                                <button type="button" class="btn btn-success" id="btn-file">Pilih Gambar</button>
                                <input id="imgfile" name="foto" type="file" style="display: none" />
                            </div>

                            <div class=" col-md-9 col-lg-9 ">
                                <table class="table table-user-information">
                                    <tbody>
                                    <tr>
                                        <td>Nama:</td>
                                        <td><input type="text" class="form-control" name="fullname" value="{{ $user->fullname }}"></td>
                                    </tr>
                                    <tr>
                                        <td>NIP:</td>
                                        <td><input type="text" class="form-control" name="nip" value="{{ $user->nip }}" readonly></td>
                                    </tr>
                                    <tr>
                                        <td>Email Company</td>
                                        <td><input type="text" class="form-control" name="email" value="{{$user->email}}" readonly> </td>
                                    </tr>
                                    <tr>
                                        <td>Jabatan:</td>
                                        <td><input type="text" class="form-control" name="jabatan" value="{{ $user->jabatan }} " readonly></td>
                                    </tr>
                                    <tr>
                                        <td>Gender</td>
                                        <td>{{ Form::select('gender', ['L' => 'Laki-Laki', 'P' => 'Perempuan'], $user->gender, ['class' => 'form-control']) }}</td>
                                    </tr>
                                    <tr>
                                        <td>Alamat</td>
                                        <td><textarea class="form-control" rows="3" name="alamat">{{$user->alamat}}</textarea></td>
                                    </tr>
                                    <tr>
                                        <td>Email Pribadi</td>
                                        <td>
<!--                                            <input type="text" class="form-control" name="private_email" value="{{$user->private_email}}"> -->
                                            <span class="email-wrap" style="margin-bottom: 5px">
                                                @if(!empty($user->private_email))
                                                @foreach($user->present()->setInputPrivateEmail as $email)
                                                <div>
                                                <input type="text" class="custom-form-control" name="private_email[]" id="private_email" value="{{ $email }}" style="width: 300px; margin-bottom: 5px">
                                                <a href="javascript:;" class="remove_field" style="display: gnone">Remove</a>
                                                </div>
                                                @endforeach 
                                                @else
                                                <div>
                                                    <input type="text" class="custom-form-control" name="private_email[]" id="private_email" style="width: 300px; margin-bottom: 5px">
                                                    <a href="javascript:;" class="remove_field" style="display: gnone">Remove</a>
                                                </div>
                                                @endif

                                            </span>
                                            <div>
                                                <!--<input type="text" class="custom-form-control" name="private_email[]" id="private_email" style="width: 300px; margin-bottom: 5px">-->

                                            </div>
                                            <a href="javascript:;" id="add-email">Tambah</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Phone Number</td>
                                        <td>

                                            <span class="phone-wrap" style="margin-bottom: 5px">
                                                @if(!empty($user->phone))
                                                @foreach($user->present()->setInputPhone as $phone)
                                                <div>
                                                    <input type="text" class="custom-form-control" name="phone[]" id="private_email" value="{{ $phone }}" style="width: 255px; margin-bottom: 5px">
                                                    <a href="javascript:;" class="remove_field" style="display: gnone">Remove</a>
                                                </div>
                                                @endforeach
                                                @else
                                                <div>
                                                    <input type="text" class="custom-form-control" name="phone[]" id="phone" style="width: 255px; margin-bottom: 5px">
                                                    <a href="javascript:;" class="remove_field" style="display: gnone">Remove</a>
                                                </div>
                                                @endif

                                            </span>
                                            <div>
                                                <!--<input type="text" class="custom-form-control" name="phone[]" id="private_email" style="width: 255px; margin-bottom: 5px">-->

                                            </div>
                                            <a href="javascript:;" id="add-phone">Tambah</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Akun Bank</td>
                                        <td>
                                            {{-- print_r(unserialize($user->bank_account)) --}}
                                            <span class="bank-wrap">
                                                @if(!empty($user->bank_account))
                                                @foreach(unserialize($user->bank_account) as $bank)
                                                <div>
                                                    <input type="text" class="custom-form-control" name="bank-name[]" value="{{ $bank['bank'] }}" placeholder="Nama Bank" style="margin-bottom: 5px;">
                                                    <input type="text" class="custom-form-control" name="an[]" value="{{ $bank['an'] }}" placeholder="Nama Akun" style="margin-bottom: 5px;">
                                                    <input type="text" class="custom-form-control" name="norek[]" value="{{ $bank['norek'] }}" placeholder="Nomer Rekening" style="margin-bottom: 5px;">
                                                    <a href="javascript:;" class="remove_field" style="display: gnone">Remove</a>
                                                </div>
                                                @endforeach
                                                @else
                                                    <input type="text" name="bank-name[]" placeholder="Nama Bank" style="margin-bottom: 5px;">
                                                    <input type="text" name="an[]" placeholder="Nama Akun" style="margin-bottom: 5px;">
                                                    <input type="text" name="norek[]" placeholder="Nomer Rekening" style="margin-bottom: 5px;">
                                                    <a href="javascript:;" class="remove_field" style="display: gnone">Remove</a>
                                                @endif
                                            </span>
                                            <br>
                                            <a href="javascript:;" id="add-bank">add</a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Status:</td>
                                        <td>{{ Form::select('status', ['K' => 'Menikah', 'TK' => 'Belum Menikah'], $user->status, ['class' => 'form-control']) }}</td>
                                    </tr>
                                    <tr>
                                        <td>Tanggungan:</td>
                                        <td><input type="text" class="form-control" name="tanggungan" value="{{ $user->tanggungan }}"> </td>
                                    </tr>
                                    <tr>
                                        <td>Hire date:</td>
                                        <td><input type="text" class="form-control" name="hiredate" value="{{ $user->hiredate }}" readonly></td>
                                    </tr>
                                    <tr>
                                        <td>Kota Lahir:</td>
                                        <td><input type="text" class="form-control" name="birthday_city" value="{{ $user->birthday_city }}"></td>
                                    </tr>
                                    <tr>
                                        <td>Tanggal Lahir</td>
                                        <td><input type="text" class="form-control" name="birthday" data-date-format="YYYY-MM-DD" id="birthday" value="{{ $user->birthday }}"></td>
                                    </tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="form-group text-center">
                            <button class="btn btn-primary"> Save </button>
                        </div>
                        {{ Form::close() }}
                    </div>
                </div>
                <div class="tab-pane" id="password">
                    {{ Form::open(['route' => ['profile.update.password', Auth::user()->id], 'method' => 'POST', 'class' => 'form-horizontal']) }}

                    <div class="form-group">
                        <label for="inputEmail3" class="col-sm-2 control-label">Password</label>
                        <div class="col-sm-4">
                            <input type="password" name="password" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="inputPassword3" class="col-sm-2 control-label">Ulangi Password</label>
                        <div class="col-sm-4">
                            <input type="password" name="password_confirmation" class="form-control">
                        </div>
                    </div>

                    <div class="form-group text-center">
                        <button class="btn btn-primary"> Save </button>
                    </div>

                    {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>
</div>

@stop

@section('scripts')
<script>
    $(document).on('click', '#add-phone', function()
    {
//        $('#phone:last').clone().val('').appendTo($(this).parent());
        $('.phone-wrap').append('<div><input type="text" class="custom-form-control" name="phone[]" style="width: 255px; margin-bottom: 5px;"/> <a href="javascript:;" class="remove_field" style="display: gnone">Remove</a></div>')

    }).on('click', '.remove_field', function()
        {
            $(this).parent('div').remove();
        }).on('click', '#add-email', function()
        {
//        $('#phone:last').clone().val('').appendTo($(this).parent());
            $('.email-wrap').append('<div><input type="text" class="custom-form-control" name="private_email[]" style="width: 300px; margin-bottom: 5px;"/> <a href="javascript:;" class="remove_field" style="display: gnone">Remove</a></div>')

        }).on('click', '#add-bank', function()
        {
//        $('#phone:last').clone().val('').appendTo($(this).parent());
            $('.bank-wrap').append('<div><input type="text" name="bank-name[]" class="custom-form-control" placeholder="Nama Bank" style="margin-bottom: 5px;"> <input class="custom-form-control" type="text" name="an[]" style="margin-bottom: 5px;" placeholder="Nama Bank"> <input type="text" class="custom-form-control" name="norek[]" placeholder="Nama Bank" style="margin-bottom: 5px;"> <a href="javascript:;" class="remove_field" style="display: gnone">Remove</a></div>')

        })

    $(document).ready(function(){
        $('#birthday').datetimepicker();

        $('#btn-file').on('click', function(){
            $('#imgfile').click();
        })

        $("#imgfile").change(function(){
            if (this.files && this.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#preview').attr('src', e.target.result);
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
    })

</script>
@stop