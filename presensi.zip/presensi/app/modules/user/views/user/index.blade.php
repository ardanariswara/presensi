@extends('layouts.default')

@section('content')

<div class="col-xs-12 col-sm-12">

    <div class="pull-right"> 
        <a href="{{ route('admin.user.create') }}" class="btn btn-success">Tambah Baru</a>
    </div>
    <h3>Pengguna</h3>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Jabatan</th>
                <th>Roles</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            @foreach($users as $key => $user)
            <tr>
                <td>#</td>
                <td>{{ $user->fullname }}</td>
                <td>{{ $user->email }}</td>
                <td>{{ $user->jabatan }}</td>
                <td>{{ $user->role }}</td>
                <td class="text-center">
                    <a href="{{ route('admin.user.edit', [$user->id]) }}" class="btn btn-default">Edit</a>
                    <a href="{{ route('user.destroy', [$user->id]) }}" class="btn btn-danger">Delete</a>
                </td>
            </tr>
            @endforeach
            <tr>
                <td colspan="6" class="text-center">
                    <div class="btn-group" role="group" aria-label="...">
                        <a href="{{ route('user.export', 'pdf') }}" target="_blank" class="btn btn-default"><i class="fa fa-file-pdf-o"></i> Export to PDF</a>
                        <a href="{{ route('user.export', 'excell') }}" target="_blank" class="btn btn-default"><i class="fa fa-file-excel-o"></i> Export to Excel</a>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>
</div><!--/.col-xs-12.col-sm-9-->

@stop