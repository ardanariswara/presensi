<?php
/**
 * Created by PhpStorm.
 * User: ardiansyah
 * Date: 11/5/14
 * Time: 2:48 AM
 */

namespace App\Modules\User\Controllers;


use App\Modules\User\Models\Role;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\View;
use App\Modules\User\Repositories\RoleRepository;
use App\Modules\User\Forms\RoleForm;

class RoleController extends \BaseController {

    protected $role;

    protected $form;

    function __construct(RoleForm $form)
    {
        $this->role = new RoleRepository();

        $this->form = $form;
    }


    public function index()
    {
        $roles = $this->role->all();

        return View::make('user::role.index', compact('roles'));
    }

    public function create()
    {
        $editMode = false;

        return View::make('user::role.form', compact('editMode'));
    }

    public function store()
    {
        $this->form->validate(Input::all());

        $this->role->create(Input::all());

        return Redirect::to('admin/role');
    }

    public function edit($id)
    {
        $role = $this->role->find($id);
        $editMode = true;
        return View::make('user::role.form', compact('role', 'editMode'));
    }

    public function update($id)
    {
        $this->form->validate(Input::all());

        $this->role->update($id, Input::all());

        return Redirect::to('admin/role');
    }

    public function destroy($id)
    {
        $this->role->destroy($id);

        return Redirect::to('admin/role');
    }

}