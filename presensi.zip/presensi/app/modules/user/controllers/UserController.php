<?php
/**
 * Created by PhpStorm.
 * User: ardiansyah
 * Date: 11/5/14
 * Time: 2:27 AM
 */

namespace App\Modules\User\Controllers;


use App\Modules\User\Forms\UserForm;
use App\Modules\User\Models\User;
use App\Modules\User\Repositories\PermissionRepository;
use App\Modules\User\Repositories\RoleRepository;
use App\Modules\User\Repositories\UserRepository;
use Barryvdh\Debugbar\Middleware\Debugbar;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\View;
use Intervention\Image\Facades\Image;
use App\Modules\User\Forms\PasswordForm;
use App\Modules\User\Classes\InputFormatter;

class UserController extends \BaseController {

    protected $user;

    protected $form;

    protected $role;

    protected $permission;

    protected $passwordForm;

    public function __construct(UserForm $form, PasswordForm $passwordForm)
    {
        $this->user = new UserRepository;

        $this->role = new RoleRepository();

        $this->form = $form;

        $this->permission = new PermissionRepository();

        $this->passwordForm = $passwordForm;
    }


    public function index()
    {
        $users = $this->user->all();
        return \View::make('user::user.index', compact('users'));
    }

    public function create()
    {
        $editMode = false;

        $roles = $this->role->all();

        // Get all the available permissions
        $permissions = $this->permission->all();

        // Selected groups
        $selectedRoles = Input::old('roles', array());

        // Selected permissions
        $selectedPermissions = Input::old('permissions', array());

        $nik = $this->user->generateNik();

        return View::make('user::user.form', compact('editMode', 'roles', 'permissions', 'selectedRoles', 'selectedPermissions', 'nik'));
    }

    public function store()
    {
        $input = Input::all();

        $this->form->validate($input);

        $this->user->create($input);

        return Redirect::to('admin/user');
    }

    public function edit($id)
    {

        $editMode = true;

        $user = $this->user->find($id);

        $userRoleId = $this->user->currentRoleIds($id);

        $roles = $this->role->all();

        return View::make('user::user.form', compact('editMode', 'roles', 'permissions', 'userRoleId', 'user'));

    }

    public function update($id)
    {
        $input = Input::all();

//        $this->form->validate($input);

        $this->user->update($id, $input);
//        var_dump($input);
        return Redirect::to('admin/user');
    }   

    public function profile()
    {
        $user = $this->user->find(Auth::user()->id);
        return View::make('user::user.profile', compact('user'));
//        Debugbar::info($user);
    }

    public function updateProfile($id)
    {
//        return InputFormatter::phoneFormatter(Input::get('phone'));
        /*$an  = Input::get('an');
        $norek = Input::get('norek');*/
        InputFormatter::bankFormatter(Input::get('bank-name'), Input::get('an'), Input::get('norek'));
        $input = Input::all();
        if (Input::hasFile('foto'))
        {
            $file = Input::file('foto');

            $destination = 'uploads/user/';
            $fileName = $this->user->generateRandomString().'_'.$file->getClientOriginalName();
            $extension = Input::file('foto')->getClientOriginalExtension();

            $uploaded = Input::file('foto')->move($destination, $fileName);

            Image::make($destination.$fileName)->resize(200,100)->save('uploads/user/thumbnail/'.$fileName);

            $data = ['nip' => $input['nip'],
                'fullname' => $input['fullname'],
                'email' => $input['email'],
                'jabatan' => $input['jabatan'],
                'alamat' => $input['alamat'],
                'status' => $input['status'],
                'foto' => $fileName,
                'tanggungan' => $input['tanggungan'],
                'gender' => $input['gender'],
                'birthday' => $input['birthday'],
                'hiredate' => $input['hiredate'],
                'phone' => InputFormatter::phoneFormatter($input['phone']),
                'private_email' => InputFormatter::phoneFormatter($input['private_email']),
                'bank_account' => InputFormatter::bankFormatter(Input::get('bank-name'), Input::get('an'), Input::get('norek')),
            ];

            $this->user->updateProfile($id, $data);
        }

        $data = ['nip' => $input['nip'],
            'fullname' => $input['fullname'],
            'email' => $input['email'],
            'jabatan' => $input['jabatan'],
            'alamat' => $input['alamat'],
            'status' => $input['status'],
            'tanggungan' => $input['tanggungan'],
            'gender' => $input['gender'],
            'birthday' => $input['birthday'],
            'hiredate' => $input['hiredate'],
            'phone' => InputFormatter::phoneFormatter($input['phone']),
            'private_email' => InputFormatter::phoneFormatter($input['private_email']),
            'bank_account' => InputFormatter::bankFormatter(Input::get('bank-name'), Input::get('an'), Input::get('norek')),
        ];

        $this->user->updateProfile($id, $data);

//        return $data;
        return Redirect::to('profile')->with('success', 'Data Anda Berhasil di Rubah');
    }

    public function updatePassword($id)
    {
        $this->passwordForm->validate(Input::all());

        $this->user->updatePassword($id, Input::all());

        return Redirect::to('profile')->with('success', 'Password Anda Berhasil di Rubah');
    }


      public function update_userdata($id)
    {

        $this->user->updatePassword($id, Input::all());
        return Redirect::to('profile')->with('success', 'Password Anda Berhasil di Rubah');
    }
    
    
    public function export($type)
    {
        if($type == 'pdf'){
            return $this->exportPdf();
        }  else {
            return $this->user->exportExcel();
        }
    }
    
    public function exportPdf()
    {
        $users = $this->user->all();
        $html = '<html><body>'
            . '<p>Put your html here, or generate it with your favourite '
            . 'templating system.</p>'
            . '</body></html>';
        return \PDF::load($html, 'A4', 'portrait')->show();
    }
    
} 