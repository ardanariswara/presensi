<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 01/11/14
 * Time: 11:33
 */

namespace App\Modules\User\Forms;


use Laracasts\Validation\FormValidator;

class UserForm extends FormValidator {

    protected $rules = [
        'nip' => 'required',
        'fullname' => 'required',
        'email' => 'required',
        'password' => 'required',
        'password_confirmation' => 'required|same:password',
        'jabatan' => 'required',
        'status' => 'required',
    ];

} 