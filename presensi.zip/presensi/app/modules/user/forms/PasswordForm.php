<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 12/11/14
 * Time: 11:27
 */

namespace App\Modules\User\Forms;


use Laracasts\Validation\FormValidator;

class PasswordForm extends FormValidator{

    protected $rules = [
        'password' => 'required',
        'password_confirmation' => 'required|same:password',
    ];

} 