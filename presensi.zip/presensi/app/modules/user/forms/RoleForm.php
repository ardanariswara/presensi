<?php
/**
 * Created by PhpStorm.
 * User: ardiansyah
 * Date: 11/5/14
 * Time: 3:15 AM
 */

namespace App\Modules\User\Forms;

use Laracasts\Validation\FormValidator;

class RoleForm extends FormValidator{

    protected $rules = [
        'name' => 'required'
    ];

} 