<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 01/11/14
 * Time: 14:22
 */

namespace App\Modules\User\Repositories;


use App\Modules\User\Models\Permission;

class PermissionRepository {

    public function all()
    {
        return Permission::all();
    }

} 