<?php

/**
 * Created by PhpStorm.
 * User: ardiansyah
 * Date: 11/5/14
 * Time: 2:49 AM
 */

namespace App\Modules\User\Repositories;

use App\Modules\User\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use stdClass;

class UserRepository {

    /**
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function all() {
        return User::all();
    }

    /**
     * @param $data
     * @return mixed
     */
    public function create($data) {
//        return $data;
        $user = User::create([
                    'nip' => $data['nip'],
                    'fullname' => $data['fullname'],
                    'email' => $data['email'],
                    'password' => Hash::make($data['password']),
                    'jabatan' => $data['jabatan'],
                    'alamat' => $data['alamat'],
                    'status' => $data['status'],
                    'tanggungan' => $data['tanggungan'],
                    'gender' => $data['gender'],
                    'birthday_city' => $data['birthday_city'],
                    'birthday' => $data['birthday'],
                    'hiredate' => $data['hiredate'],
                    'gaji_pokok' => $data['gaji_pokok'],
                    'tunjangan' => $data['tunjangan']
        ]);

        $saveRole = new User();

        $user->saveRoles($data['roles']);

        return $user->id;
    }

    /**
     * @param $id
     * @param $data
     */
    public function update($id, $data) {
        $user = User::find($id);

        /* if(empty($data['password']))
          {
          $user->fill(['nip' => $data['nip'],
          'fullname' => $data['fullname'],
          'email' => $data['email'],
          'jabatan' => $data['jabatan'],
          'alamat' => $data['alamat'],
          'status' => $data['status'],
          'tanggungan' => $data['tanggungan']
          ]);
          } */
        
//                var_dump($data);

        $tunjangan = isset($data['tunjangan']) ? $data['tunjangan'] : 0; 
        
        $user->fill(['nip' => $data['nip'],
            'fullname' => $data['fullname'],
            'email' => $data['email'],
//            'password' => Hash::make($data['password']),
            'jabatan' => $data['jabatan'],
            'alamat' => $data['alamat'],
            'status' => $data['status'],
            'tanggungan' => $data['tanggungan'],
            'gender' => $data['gender'],
            'birthday_city' => $data['birthday_city'],
            'birthday' => $data['birthday'],
            'hiredate' => $data['hiredate'],
            'gaji_pokok' => $data['gaji_pokok'],
            'tunjangan' => $tunjangan
        ]);

        $user->save();

        $user->saveRoles($data['roles']);
    }

    /**
     * @param $id
     * @return \Illuminate\Database\Eloquent\Model|\Illuminate\Support\Collection|null|static
     */
    public function find($id) {
        return User::with('roles')->find($id);
    }

    /**
     * @param $id
     * @return object
     */
    public function findProfile($id) {
        $users = User::find($id);
//        dd($users);
//        $object = new stdClass;
        $object = [];

//        foreach($users as $user){
        $object['id'] = $users->id;
        $object['email'] = $users->email;
        $object['nip'] = $users->nip;
        $object['fullname'] = $users->fullname;
        $object['jabatan'] = $users->jabatan;
        $object['alamat'] = $users->alamat;
        $object['status'] = $users->status;
        $object['tanggungan'] = $users->tanggungan;
        $object['foto'] = $users->foto;
        $object['gender'] = $users->gender;
        $object['birthday'] = $users->birthday;
        $object['hiredate'] = $users->hiredate;
        $object['gaji_pokok'] = $users->gaji_pokok;
        $object['phones'] = $this->fetchingPhoneNumber($users->phone);
        $object['private_email'] = $this->fetchingPrivateEmail($users->private_email);
        $object['tunjangan'] = $users->tunjangan;

//        }

        return (object) $object;
    }

    /**
     * @param $id
     * @return \Illuminate\Support\Collection|static
     */
    public function findUser($id) {
        return User::find($id);
    }

    /**
     * @param $id
     * @return array|bool
     */
    public function currentRoleIds($id) {
        $user = User::with('roles')->find($id);
        $roleIds = false;
        if (!empty($user->roles)) {
            $roleIds = array();
            foreach ($user->roles as $role) {
                $roleIds[] = $role->id;
            }
        }
        return $roleIds;
    }

    /**
     * @param $id
     * @param $data
     */
    public function updateProfile($id, $data) {
        $user = User::find($id);

        $user->fill($data);

        $user->save();
    }

    /**
     * @param $id
     * @return mixed
     */
    public function getDataUserSignIn($id) { 
//        return User::with('presensi')->find($id);
$month_start = date('m') -1 ;
        return DB::table('users')
                        ->join('presensi', 'users.id', '=', 'presensi.user_id')
                        ->whereRaw('users.id = ' . $id . ' and MONTH(FROM_UNIXTIME(presensi.date)) = ' . $month_start . ' and YEAR(FROM_UNIXTIME(presensi.date)) = ' . date('Y'))
                        ->select('presensi.id', 'presensi.signin', 'presensi.signout', 'presensi.date', 'presensi.user_id')
                        ->get();
    }

    /**
     * @param $id
     * @param $month
     * @param $year
     * @return mixed
     */
    public function getDataUserSignInByDate($id, $month, $year) {
//        return User::with('presensi')->find($id);
//        return User::whereRaw('id = '.$id.' and MONTH(FROM_UNIXTIME(date)) = '.$month.' and YEAR(FROM_UNIXTIME(date)) = '. $year)->get();
        $month_start = $month - 1;
        $date_start = $year . '-' . $month_start . '-' . DATE_START;
        if($month == 12){
         $date_end = $year+1 . '-' . ($month) . '-' . DATE_END;
        }else {
          $date_end = $year . '-' . ($month + 1) . '-' . DATE_END;
        }
        return DB::table('users')
                        ->join('presensi', 'users.id', '=', 'presensi.user_id')
                        ->whereRaw('users.id = ' . $id . ' and DATE(FROM_UNIXTIME(presensi.date)) between "' . $date_start . '" and "' . $date_end . '"')
                        ->select('presensi.id', 'presensi.signin', 'presensi.signout', 'presensi.date', 'presensi.user_id')
                        ->get();
    }

    /**
     * @param int $length
     * @return string
     */
    public function generateRandomString($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $randomString = '';
        for ($i = 0; $i < $length; $i++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }

    /**
     * @param $id
     * @param $data
     */
    public function updatePassword($id, $data) {
        $user = User::find($id);

        $user->fill(['password' => Hash::make($data['password'])]);

        $user->save();
    }

    /**
     * @param $data
     * @return mixed
     */
    public function fetchingPhoneNumber($data) {
        $explodes = explode('|', $data);
        foreach ($explodes as $key => $exp) {
            $phone[$key]['number'] = $exp;
        }

        return $phone;
    }

    /**
     * @param $data
     * @return mixed
     */
    public function fetchingPrivateEmail($data) {
        $explodes = explode('|', $data);
        foreach ($explodes as $key => $exp) {
            $phone[$key]['email'] = $exp;
        }

        return $phone;
    }

    /**
     * @return string
     */
    public function generateNik() {
        $userCount = User::count();

        $number = date('y') . '' . str_pad($userCount + 1, 4, "0", STR_PAD_LEFT);

        return $number;
    }

    public function exportExcel() {
//        \Excel::create('Filename', function($excel) {
//
//            $excel->sheet('Sheetname', function($sheet) {
//
//                $sheet->fromArray(array(
//                    array('as', 'name' => 'data1', 'data' => 'data2'),
//                ));
//                
//                $sheet->freezeFirstRowAndColumn();
//
//            });
//
//        })->export('xls');
    }

}
