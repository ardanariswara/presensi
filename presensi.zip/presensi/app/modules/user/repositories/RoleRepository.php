<?php
/**
 * Created by PhpStorm.
 * User: ardiansyah
 * Date: 11/5/14
 * Time: 2:49 AM
 */

namespace App\Modules\User\Repositories;

use App\Modules\User\Models\Role;
class RoleRepository {

    /**
     * @return \Illuminate\Database\Eloquent\Collection|static[]
     */
    public function all()
    {
        return Role::all();
    }

    /**
     * @param $data
     * @return static
     */
    public function create($data)
    {
        return Role::create([
            'name' => $data['name']
        ]);
    }

    /**
     * @param $id
     * @return \LaravelBook\Ardent\Ardent|\LaravelBook\Ardent\Collection
     */
    public function find($id)
    {
        return Role::find($id);
    }

    /**
     * @param $id
     * @param $data
     */
    public function update($id, $data)
    {
//        return $data;
        $role = Role::find($id);

        $role->fill([
            'name' => $data['name']
        ]);

        $role->save();
    }

    public function destroy($id)
    {
        return Role::destroy([$id]);
    }

    public function lists()
    {
        return Role::lists('name', 'id');
    }



} 