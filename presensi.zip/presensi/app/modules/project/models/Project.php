<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 14/11/14
 * Time: 11:10
 */

namespace App\Modules\Project\Models;


use Illuminate\Database\Eloquent\Model;
use Laracasts\Presenter\PresentableTrait;

class Project extends Model {

    use PresentableTrait;

    protected $table = 'projects';

    protected $fillable = ['name', 'description', 'start', 'end', 'user_id'];

    protected $dates = ['deleted_at'];

    protected $presenter = 'App\Modules\Project\Presenters\ProjectPresenter';

    public function todo()
    {
        return $this->hasMany('App\Modules\Project\Models\ProjectTodo');
    }

} 