<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 14/11/14
 * Time: 11:13
 */

namespace App\Modules\Project\Models;


use Illuminate\Database\Eloquent\Model;

class ProjectTodo extends Model {

    protected $table = 'project_todo';

    protected $fillable = ['name', 'description', 'start', 'end', 'user_id', 'parent_id', 'project_id'];

    protected $dates = ['deleted_at'];

    public function children()
    {
        return $this->hasMany('App\Modules\Project\Models\ProjectTodo','parent_id');
    }

    public function parent()
    {
        return $this->belongsTo('App\Modules\Project\Models\ProjectTodo','parent_id');
    }

    public function project()
    {
        return $this->belongsTo('App\Modules\Project\Models\Project','project_id');
    }

} 