<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 15/11/14
 * Time: 10:58
 */

namespace App\Modules\Project\Presenters;


use Laracasts\Presenter\Presenter;
use Carbon\Carbon;

class ProjectPresenter extends Presenter {

    public function days()
    {
        $start = Carbon::parse($this->start);

        $end = Carbon::parse($this->end);

        $days = $start->diffInDays($end);

        return $days;
    }

} 