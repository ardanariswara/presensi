<?php
Route::group(['prefix' => 'admin', 'before' => ['auth', 'admin'], 'namespace' => 'App\Modules\Project\Controllers'], function(){
    Route::get('project', ['uses' => 'ProjectController@index', 'as' => 'project.index']);
    Route::get('project/{id}', ['uses' => 'ProjectController@show', 'as' => 'project.show']);
    Route::post('project/todo/resize/{id}', ['uses' => 'ProjectTodoController@resizeOrMoveEvents', 'as' => 'todo.resize']);
    Route::post('project/todo/move/{id}', ['uses' => 'ProjectTodoController@resizeOrMoveEvents', 'as' => 'todo.move']);
    Route::post('project/todo/createEvent/{id}', ['uses' => 'ProjectTodoController@createEvent', 'as' => 'todo.createEvent']);
    Route::post('project/todo/{id}/createResource', ['uses' => 'ProjectTodoController@createResource', 'as' => 'todo.createResource']);
    Route::post('project/todo/moveRows/{id}', ['uses' => 'ProjectTodoController@moveRows', 'as' => 'todo.moveRows']);
    Route::get('project/todo/modal/create', ['uses' => 'ProjectTodoController@modalCreate', 'as' => 'todo._modalCreate']);
});

Route::group(['prefix' => 'api', 'before' => ['auth', 'admin'], 'namespace' => 'App\Modules\Project\Controllers\Api'], function(){
    Route::get('project/resources/{id}', ['uses' => 'ProjectController@getResourceTodoLists', 'as' => 'project.api.resources']);
    Route::get('project/todo/{id}', ['uses' => 'ProjectController@getTodoLists', 'as' => 'project.api.todo']);
    Route::get('project/events/{id}', ['uses' => 'ProjectController@getEventTodoLists', 'as' => 'project.api.events']);
    Route::get('project/todo/modal/{id}/create', ['uses' => 'ProjectController@modalCreate', 'as' => 'project.api._modalCreate']);
});

Route::group(['before' => ['auth'], 'namespace' => 'App\Modules\Project\Controllers\Member'], function(){

    Route::get('project', ['uses' => 'ProjectController@index', 'as' => 'member.project.index']);

});