<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 15/11/14
 * Time: 12:14
 */

namespace App\Modules\Project\Controllers\Api;

use App\Modules\User\Models\User;
use BaseController;
use App\Modules\Project\Repositories\ProjectTodoRepository;
use App\Modules\Project\Libraries\ProjectLists;
use Carbon\Carbon;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\View;

class ProjectController extends BaseController {

    protected $todo;

    function __construct(ProjectTodoRepository $todoRepository)
    {

        $this->todo = $todoRepository;

    }

    public function getResourceTodoLists($id)
    {
        $item = new ProjectLists();

        $resdata = $this->todo->findOnlyParentByProjectId($id);

        $resource = $item->resourceArray($resdata);

//        return $resource;

        return Response::json($resource);
    }

    public function getEventTodoLists($id)
    {
        $item = new ProjectLists();

        $events = $item->eventsArray($this->todo->findEventsByProjectId($id));

//        return json_encode($events);
        return Response::json($events);
    }

    public function modalCreate($id)
    {
        $item = new ProjectLists();

        $resdata = $this->todo->findOnlyParentByProjectId($id);

        $resource = $item->resourceArray($resdata);
        $start = Carbon::parse($_GET['start'])->format('Y-m-d');
        $end = Carbon::parse($_GET['end'])->format('Y-m-d');
        $parent = $_GET['r'];

        $users = User::get(['fullname', 'id']);

        return View::make('project::_modalCreate', compact('resource', 'start', 'end', 'parent', 'users'));

    }

    public function getTodoLists($id)
    {
        $item = new ProjectLists();

        $resdata = $this->todo->findOnlyParentByProjectId($id);

        $resource = $item->todosArray($resdata);

        $resource = ['list' => $resource];

        return Response::json($resource);
    }

} 