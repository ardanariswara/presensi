<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 13/11/14
 * Time: 16:33
 */

namespace App\Modules\Project\Controllers;


use App\Modules\Project\Models\ProjectTodo;
use App\Modules\Project\Repositories\ProjectTodoRepository;
use Barryvdh\Debugbar\Controllers\BaseController;
use Illuminate\Support\Facades\View;
use App\Modules\Project\Repositories\ProjectRepository;
use App\Modules\Project\Libraries\ProjectLists;
use stdClass;

class ProjectController extends BaseController{

    protected $project;

    protected $todo;

    function __construct(ProjectRepository $project, ProjectTodoRepository $todoRepository)
    {
        $this->project = $project;

        $this->todo = $todoRepository;
    }

    public function index()
    {

    }

    public function show($id)
    {
        $item = new ProjectLists();

        $resdata = $this->todo->findOnlyParentByProjectId($id);

        $resource = $item->resourceArray($resdata);

        $project = $this->project->find($id);

        $events = $item->eventsArray($this->todo->findEventsByProjectId($id));

        return View::make('project::show', compact('resource','project', 'events'));
    }

} 