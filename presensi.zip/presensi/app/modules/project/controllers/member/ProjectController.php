<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 18/11/14
 * Time: 10:53
 */

namespace App\Modules\Project\Controllers\Member;


use App\Modules\Project\Repositories\ProjectRepository;
use App\Modules\Project\Repositories\ProjectTodoRepository;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\View;

class ProjectController extends \BaseController {

    protected $todo;

    protected $project;

    public function __construct(ProjectTodoRepository $todo, ProjectRepository $project)
    {
        $this->project = $project;

        $this->todo = $todo;
    }

    public function index()
    {

        $projects = $this->project->findByAssigned(Auth::user()->id);

        return View::make('project::member.index', compact('projects'));

    }

} 