<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 15/11/14
 * Time: 11:25
 */

namespace App\Modules\Project\Controllers;

use App\Modules\Project\Repositories\ProjectTodoRepository;
use Barryvdh\Debugbar\Controllers\BaseController;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\View;

class ProjectTodoController extends BaseController {

    protected $todo;

    public function __construct(ProjectTodoRepository $todo)
    {
        $this->todo = $todo;
    }

    public function resizeOrMoveEvents($id)
    {

        $input = Input::all();
        $this->todo->update($id, [
            'start' => $input['start'],
            'end' => $input['end']
        ]);

    }

    public function createResource($pid)
    {
        $input = Input::all();

        return $this->todo->create([
            'name' => $input['name'],
            'project_id' => $pid
        ]);

    }

    public function createEvent($id)
    {
        $find =  $this->todo->find($id);
        if($find->start == '' || $find->end == ''){
            $input = Input::all();
            $this->todo->update($id, [
                'start' => $input['start'],
                'end' => $input['end']
            ]);
            $response = array(
                'status' => 'success',
                'msg' => 'Event created successfully',
                'source' => $find
            );
        }else{
            $response = array(
                'status' => 'error',
                'msg' => 'Event cannot create here',
            );
        }

        return  $response;
//        return $this->todo->find($id);
    }

    public function moveRows($id)
    {
        $input = Input::all();

        $this->todo->update($id, [
            'parent_id' => $input['parent_id']
        ]);
    }

    public function modalCreate()
    {
        return View::make('project::_modalCreate');

    }


} 