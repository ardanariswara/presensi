<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 14/11/14
 * Time: 11:22
 */

namespace App\Modules\Project\Repositories;

use App\Modules\Project\Models\Project;

class ProjectRepository {

    public function all()
    {
        return Project::all();
    }

    public function allLists()
    {
        return Project::with('todo', 'todo.children')->get();
//        return Project::todo()->children()->get();
    }

    public function find($id)
    {
        return Project::find($id);
    }

    public function findByAssigned($id)
    {
        return Project::where('user_id', '=', $id)->get(['id', 'name']);
    }

} 