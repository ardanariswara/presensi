<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 14/11/14
 * Time: 14:15
 */

namespace App\Modules\Project\Repositories;


use App\Modules\Project\Models\ProjectTodo;

class ProjectTodoRepository {

    public function findOnlyParentByProjectId($projectId)
    {
        return ProjectTodo::where('project_id', '=', $projectId)->where('parent_id', '=', null)->with('children')->get();
    }

    public function findByProjectId($projectId)
    {
        return ProjectTodo::where('project_id', '=', $projectId)->get();
    }

    public function findEventsByProjectId($projectId)
    {
        return ProjectTodo::where('project_id', '=', $projectId)->where('start', '!=', '')->where('end', '!=', '')->get();
    }

    public function update($id, $data)
    {
        $todo = ProjectTodo::find($id);

        $todo->fill($data);

        $todo->save();

    }

    public function find($id)
    {
        return ProjectTodo::find($id);
    }

    public function create($data)
    {
        return ProjectTodo::create($data);
    }

} 