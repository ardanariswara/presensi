<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 14/11/14
 * Time: 12:35
 */

namespace App\Modules\Project\Libraries;
use Carbon\Carbon;

class ProjectLists {

    public  function resourceArray($items) {
        $result = array();
        foreach($items as $key => $res){
            if( count($res->children) > 0){
                $resource[$key]['name'] = $res->name;
                $resource[$key]['id'] = (string) $res->id;
                $resource[$key]['expanded'] = true;
                foreach($res->children as $i => $child){
                    $children[$i]['name'] = $child->name;
                    $children[$i]['id'] = (string) $child->id;
                }
                $resource[$key]['children'] = $children;
            }else{
                $resource[$key]['name'] = $res->name;
                $resource[$key]['id'] = (string) $res->id;
                $resource[$key]['expanded'] = true;
            }
        }
        return $resource;
    }

    public function eventsArray($items)
    {
        foreach($items as $key => $event){
            $events[$key]['start'] = $event->start;
            $events[$key]['end'] = $event->end;
            $events[$key]['id'] = (string)$event->id;
            $events[$key]['resource'] = (string)$event->id;
//            $events[$key]['text'] = $event->name;
            $events[$key]['text'] ='';
        }

        return $events;
    }

    public  function todosArray($items) {
        $result = array();
        foreach($items as $key => $res){
            if( count($res->children) > 0){
                $resource[$key]['name'] = $res->name;
                $resource[$key]['id'] = (string) $res->id;
                $resource[$key]['expanded'] = true;
                foreach($res->children as $i => $child){
                    $children[$i]['name'] = $child->name;
                    $children[$i]['id'] = (string) $child->id;
                }
                $resource[$key]['children'] = $children;
            }else{
                $resource[$key]['name'] = $res->name;
                $resource[$key]['id'] = (string) $res->id;
                $resource[$key]['expanded'] = true;
                $resource[$key]['children'] = [];
            }
        }
        return $resource;
    }

} 