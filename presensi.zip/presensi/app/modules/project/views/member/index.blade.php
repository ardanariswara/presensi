@extends('layouts.default')

@section('content')

<div class="rows">
    <div class="dual-list list-left col-md-4">
        <div class="well text-rightl">
            <div class="row">
                <div class="col-md-12">
                    <div class="input-group">
                        <span class="input-group-addon glyphicon glyphicon-search"></span>
                        <input type="text" name="SearchDualList" class="form-control" placeholder="search" />
                    </div>
                </div>
            </div>
            <ul class="list-group" data-bind="foreach: projects, visible: projects().length > 0 ">
                <li class="list-group-item" data-bind="text: $data.name, css: { active: $data.id == $root.chosenProjectId() }, click: $root.goToProject"></li>
            </ul>
        </div>
    </div>
    <div class="col-md-8">
        <!--<div class="easy-tree">
            <ul>
                <li>Example 1</li>
                <li>Example 2</li>
                <li>Example 3
                    <ul>
                        <li>Example 1</li>
                        <li>Example 2
                            <ul>
                                <li>Example 1</li>
                                <li>Example 2</li>
                                <li>Example 3</li>
                                <li>Example 4</li>
                            </ul>
                        </li>
                        <li>Example 3</li>
                        <li>Example 4</li>
                    </ul>
                </li>
                <li>Example 0
                    <ul>
                        <li>Example 1</li>
                        <li>Example 2</li>
                        <li>Example 3</li>
                        <li>Example 4
                            <ul>
                                <li>Example 1</li>
                                <li>Example 2</li>
                                <li>Example 3</li>
                                <li>Example 4</li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ul>
        </div>-->
        <div data-bind="with: chosenProjectTodo">
            <div class="easy-tree">
                <ul data-bind="foreach: list">
                    <li data-bind="text: name"></li>
                    <ul data-bind="foreach: children">
                        <li data-bind="text: name"></li>
                    </ul>
                </ul>
                <!--<ul data-bind="foreach: list">
                    <li data-bind="text: name"></li>
                    <ul data-bind="foreach: children">
                        <li data-bind="text: name"></li>
                    </ul>
                </ul>-->
            </div>


        </div>

        <!--<table class="lists" data-bind="with: chosenProjectTodo">
            <thead><tr><th>From</th><th>To</th><th>Subject</th><th>Date</th></tr></thead>
            <tbody data-bind="foreach: list">
            <tr>
                    <td data-bind="text: name"></td>
<!--                <td data-bind="text: id"></td>
            </tr>
            </tbody>
        </table>-->
    </div>
</div>

@stop

@section('styles')

<link rel="stylesheet" href="{{asset('assets/css/easyTree.css')}}">

@stop

@section('scripts')

<script src="{{asset('assets/js/knockout-3.2.0.js') }}"></script>
<script src="{{asset('assets/js/easyTree.js') }}"></script>
<script>
    $(function(){
        $('.easy-tree').EasyTree();
    })
</script>
<script>

    var projectsData = {{ $projects }};

    var base_url = "{{ Request::root()}}";

    function ProjectsModel( projects ){
        var self = this;
        self.projects = ko.observableArray(ko.utils.arrayMap(projects, function(project) {
            return { name: project.name, id: project.id };
        }));

        self.chosenProjectId = ko.observable();

        self.chosenProjectTodo = ko.observable();

        self.goToProject = function(projects) {

            var id = projects.id;
            self.chosenProjectId(projects.id);
            /*$.get(base_url+'/api/project/resources/'+projects.id, function(data) {
                console.log(data)
                self.chosenProjectTodo = ko.observableArray(ko.utils.arrayMap(data, function(todo){
                    return { name : todo.name, id: todo.id, children: todo.children }
                }));
            })*/

            $.get(base_url+'/api/project/todo/'+projects.id, self.chosenProjectTodo);

        };
    }

    ko.applyBindings(new ProjectsModel(projectsData));
</script>

@stop