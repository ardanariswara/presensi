@extends('layouts.default')

@section('content')

<div id="dp"></div>

@stop

@section('scripts')
<script src="{{asset('assets/js/daypilot-all.min.js') }}"></script>
<script src="{{asset('assets/js/daypilot-modal-2.1.js') }}"></script>

<script type="text/javascript">
    var base_url = "{{ Request::root()}}";
    var pid = {{ $project->id }};
    var dp = new DayPilot.Scheduler("dp");
/* Event editing helpers - modal dialog */
    function dialog() {
        var modal = new DayPilot.Modal();
        modal.top = 60;
        modal.width = 400;
        modal.opacity = 70;
        modal.border = "10px solid #d0d0d0";
        modal.closed = function() {
            if(this.result == "OK") {
                dps1.commandCallBack('refresh');
            }
            dps1.clearSelection();
        };

        modal.height = 250;
        modal.zIndex = 100;
        return modal;
    }

    function timeRangeSelected(start, end, resource) {
        var modal = dialog();
//        console.log(start.value);
        modal.showUrl(base_url+"api/project/todo/modal/"+ pid +"/create?start=" + start + "&end=" + end + "&r=" + resource);
//        modal.showUrl(base_url+"api/project/todo/modal/create?start=");
    }

    function eventClick(e) {
        var modal = dialog();
        modal.showUrl("Edit.aspx?id=" + e.value() + "&hash=paTgzWqJ5gF-yA27KlY7IQVKrB4.");
    }


//    var resource = {{json_encode($resource)}};


    dp.startDate = "{{ $project->start }}";  // or just dp.startDate = "2013-03-25";
    dp.days = {{ $project->present()->days }};
    dp.scale = "Day";
    dp.timeHeaders = [
        { groupBy: "Month", format: "MMM yyyy" },
        { groupBy: "Cell", format: "ddd d" }
    ];
    dp.treeEnabled = true;
    dp.rowCreateHandling = "Enabled";
    dp.onRowCreate = function(args){
        console.log(args);
        $.post(base_url +'/admin/project/todo/'+ pid +'/createResource', {
            name : args.text
        })
            .done(function(data){
                dp.resources.push({
                    id: data.id,
                    name: args.text
                });
                dp.update();

            })
    };
    dp.rowMoveHandling = 'Update';
    dp.onRowMove = function(args){
        console.log(args);
        $.post(base_url+'/admin/project/todo/moveRows/'+args.source.id, {
            parent_id : args.target.id
        })
            .done(function(){
                dp.message("Row Moved");
            });
    };
//    dp.eventMovingStartEndEnabled = true;
//    dp.eventResizingStartEndEnabled = true;
//    dp.timeRangeSelectingStartEndEnabled = true;
    dp.onEventMoved = function (args) {
        $.post(base_url+'/admin/project/todo/move/'+args.e.id(), {
            start : args.newStart.value,
            end : args.newEnd.value
        })
            .done(function(data){
                dp.message("Moved: " + args.e.text());
            })
    };
    dp.onEventResized = function (args) {
        dp.message("Resized: " + args.e.text());
        console.log(args.newStart.value);
        console.log(args.newEnd.value);
        $.post(base_url+'/admin/project/todo/resize/'+args.e.id(), {
            start : args.newStart.value,
            end : args.newEnd.value
        })
            .done(function(data){

            })
    };
    dp.useEventBoxes = "Never";
    dp.onTimeRangeSelected = function (args, start, end, resource) {
        console.log(args)
        var column = resource;
        timeRangeSelected(args.start.toStringSortable(), args.end.toStringSortable(), args.resource);
        /*$.post(base_url+'/admin/project/todo/createEvent/'+args.resource, {
            start : args.start.value,
            end : args.end.value
        })
            .done(function(data){
                console.log(data);
                if(data.status == 'success'){
                    var e = new DayPilot.Event({
                        start: args.start,
                        end: args.end,
                        id: args.resource,
                        resource: args.resource,
                        text: name
                    });
//                            dp.message("Resized: " + args.e.text());
                    dp.events.add(e);
                    dp.message("Created");
                }else{
                    dp.message("Created " + data.msg);
                }
            })*/
    },
    dp.init();

    dp.rows.load(base_url+'/api/project/resources/'+pid);
    dp.events.load(base_url+'/api/project/events/'+pid);

    /*var dp;

    $(document).ready(function() {
        var resource = {{json_encode($resource)}};
        var event = {{json_encode($events)}};
        var base_url = "{{ Request::root()}}";
        var pid = {{ $project->id }};
        var options = {
            startDate: "{{ $project->start }}",
            days: "{{ $project->present()->days }}",
            scale: "Day",
            timeHeaders: [
                { groupBy: "Month", format: "MMM yyyy" },
                { groupBy: "Cell", format: "d" }
            ],
            treeEnabled: true,
//            theme : "fiss",
            rowMoveHandling : "Update",
            onRowMove : function(args){
                console.log(args);
                *//*if (args.position === "before" || args.position === "after") {
                    args.position = "forbidden";
                    dp.message("Forbidden Move");
                }
                $.post(base_url+'/admin/project/todo/moveRows/'+args.source.id, {
                    parent_id : args.target.id
                })
                    .done(function(){
                        dp.message("Row Moved");
                    });

                console.log("source: " + args.source.id  + ", target: " + args.target.id + ", position: " + args.position);*//*
            },
            rowClickHandling : "Edit",
            onRowEdit : function(args){
                console.log(args);
//                dp.message("Row text changed to " + args.newText);
            },
            resources: resource,
            events: event,
            // event moving
            onEventMoved: function (args) {
                $.post(base_url+'/admin/project/todo/move/'+args.e.id(), {
                    start : args.newStart.value,
                    end : args.newEnd.value
                })
                    .done(function(data){
                        dp.message("Moved: " + args.e.text());
                    })
            },
            // event resizing
            onEventResized: function (args) {
                dp.message("Resized: " + args.e.text());
                console.log(args.newStart.value);
                console.log(args.newEnd.value);
                $.post(base_url+'/admin/project/todo/resize/'+args.e.id(), {
                    start : args.newStart.value,
                    end : args.newEnd.value
                })
                    .done(function(data){

                    })
            },
            useEventBoxes : "Never",
            // event creating
            onTimeRangeSelected: function (args) {
                console.log(args);
                $.post(base_url+'/admin/project/todo/createEvent/'+args.resource, {
                    start : args.start.value,
                    end : args.end.value
                })
                    .done(function(data){
                        console.log(data);
                        if(data.status == 'success'){
                            var e = new DayPilot.Event({
                                start: args.start,
                                end: args.end,
                                id: args.resource,
                                resource: args.resource,
                                text: name
                            });
//                            dp.message("Resized: " + args.e.text());
                            dp.events.add(e);
                            dp.message("Created");
                        }else{
                            dp.message("Created " + data.msg);
                        }
                    })
            },
            rowCreateHandling : "Enabled",
            onRowCreate : function(args){
                console.log(args);
                $.post(base_url +'/admin/project/todo/'+ pid +'/createResource', {
                    name : args.text
                })
                    .done(function(data){
                        dp.resources.push({
                            id: data.id,
                            name: args.text
                        });
                        dp.update();

                    })
            },
            scrollTo: "2014-03-20"

        };

        dp = $("#dp").daypilotScheduler(options);

    });*/

</script>

@stop