@extends('layouts.default')

@section('content')

<table class="table table-bordered">

</table>

@stop
