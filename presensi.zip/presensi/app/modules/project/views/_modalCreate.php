
<script>
    $('#TextBoxStart, #TextBoxEnd').datetimepicker();
</script>
<style>
    .datepicker{z-index:1151 !important;}
</style>

<div>
    <table border="0" cellspacing="4" cellpadding="0">
        <tr>
            <td align="right"></td>
            <td>
                <h2>New Event</h2>
            </td>
        </tr>
        <tr>
            <td align="right">Start:</td>
            <td><input name="TextBoxStart" id="TextBoxStart" type="text" value="<?= $start ?>" id="TextBoxStart" /></td>
        </tr>
        <tr>
            <td align="right">End:</td>
            <td><input name="TextBoxEnd" id="TextBoxEnd" type="text" value="<?= $end ?>" id="TextBoxEnd" /></td>
        </tr>
        <tr>
            <td align="right">Resource:</td>
            <td><select name="DropDownList1" id="DropDownList1">
                    <?php foreach($resource as $res) : ?>
                    <option value="<?= $res['id'] ?>"><?= $res['name'] ?></option>
                    <?php endforeach; ?>
                </select></td>
        </tr>
        <tr>
            <td align="right">User:</td>
            <td><select name="DropDownList2" id="DropDownList2">
                    <?php foreach($users as $user): ?>
                    <option value="<?= $user->id ?>"><?= $user->fullname ?></option>
                    <?php endforeach; ?>
                </select></td>
        </tr>
        <tr>
            <td align="right">Name:</td>
            <td><input name="TextBoxName" type="text" id="TextBoxName" /></td>
        </tr>
        <tr>
            <td align="right"></td>
            <td>
                <input type="submit" name="ButtonOK" value="OK" id="ButtonOK" />
                <input type="submit" name="ButtonCancel" value="Cancel" id="ButtonCancel" />
            </td>
        </tr>
        <
    </table>
</div>