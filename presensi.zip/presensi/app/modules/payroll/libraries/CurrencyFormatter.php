<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 11/11/14
 * Time: 10:18
 */

namespace App\Modules\Payroll\Libraries;


class CurrencyFormatter {

    public static function format($number)
    {
        return number_format($number, 0, ',', '.');
    }

} 