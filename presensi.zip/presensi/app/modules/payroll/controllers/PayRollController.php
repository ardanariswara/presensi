<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 08/11/14
 * Time: 15:01
 */

namespace App\Modules\Payroll\Controllers;


use App\Modules\Attributes\Repositories\AttributeValueRepository;
use Barryvdh\Debugbar\Controllers\BaseController;
use Illuminate\Support\Facades\View;
use App\Modules\User\Repositories\UserRepository;
use App\Modules\Attributes\Repositories\AttributeRepository;
use App\Modules\Presensi\Repositories\PresensiRepository;
use App\Modules\Payroll\Repositories\PayRollRepository;
use Thujohn\Pdf\Pdf as PDF;
use App\Modules\Attributes\Models\Attribute as AttributeModel;

class PayRollController extends BaseController{

    protected $user;
    protected $attribute;
    protected $presensi;
    protected $payroll;
    protected $attributeValue;

    function __construct(AttributeRepository $attribute, UserRepository $user, PresensiRepository $presensi, PayRollRepository $payRoll, AttributeValueRepository $attributeValue)
    {
        $this->attribute = $attribute;
        $this->user = $user;
        $this->presensi = $presensi;
        $this->payroll = $payRoll;
        $this->attributeValue = $attributeValue;
    }

    public function index()
    {
        $users = $this->user->all();
        return View::make('payroll::index', compact('users'));
    }

    public function show()
    {
        // return 'a';
        $id = $_GET['user_id'];
        $month = isset($_GET['month']) ? $_GET['month'] : date('m');
        $year = isset($_GET['month']) ? $_GET['year'] : date('Y');

//        $users = $this->user->all();
        $overTime =  $this->presensi->getOverTimeByMonth($id, $month, $year);
        
        $lateTime = $this->presensi->getLateByMonth($id, $month, $year);
        $attributEarnings = $this->attribute->earningAttributes();
        $attributDeductions = $this->attribute->deductionAttributes();
        $users = $this->user->all();
        $findUser = $this->user->findUser($id);
        $payslip = $this->payroll->findByDate($id, $month.'-'.$year);
        if( ! $payslip ){
            return View::make('payroll::show', compact('users', 'findUser','overTime', 'lateTime', 'attributEarnings', 'attributDeductions'));
        }else{
            return View::make('payroll::update', compact('users', 'findUser','overTime', 'lateTime', 'attributEarnings', 'attributDeductions', 'payslip'));
        }
    }

    public function store($id)
    {
//        return $id;

        $input = \Input::all();

        $payslip  = $this->payroll->store($input);

        $attribute_deduction = json_decode(\Input::get('attribute_deduction'));
        $attribute_earning = json_decode(\Input::get('attribute_earning'));

        // attribute value earning record
        foreach($attribute_earning as $earnings)
        {
            $itemRecord = [
                'attribute_id' => $earnings->attributes,
                'payslip_id' => $payslip->id,
                'value' => $earnings->attribute_values,
            ];

            $this->attributeValue->store($itemRecord);
        }

        // attribute value deduction record
        foreach($attribute_deduction as $deductions)
        { 
            $itemRecord = [
                'attribute_id' => $deductions->attributes,
                'payslip_id' => $payslip->id,
                'value' => $deductions->attribute_values,
            ];

            $this->attributeValue->store($itemRecord);
        }
    }

    public function update($payslip_id)
    {
        $input = \Input::all();

        $payslip  = $this->payroll->update($payslip_id, $input);

        $attribute_deduction = json_decode(\Input::get('attribute_deduction'));
        $attribute_earning = json_decode(\Input::get('attribute_earning'));

        $this->attributeValue->deleteByPaySlipId($payslip_id);

        // attribute value earning record
        foreach($attribute_earning as $earnings)
        {
            $itemRecord = [
                'attribute_id' => $earnings->attributes,
                'payslip_id' => $payslip_id,
                'value' => $earnings->attribute_values,
            ];

            $this->attributeValue->store($itemRecord);
        }

        // attribute value deduction record
        foreach($attribute_deduction as $deductions)
        { 
            $itemRecord = [
                'attribute_id' => $deductions->attributes,
                'payslip_id' => $payslip_id,
                'value' => $deductions->attribute_values,
            ];

            $this->attributeValue->store($itemRecord);
        }
    }

    public function pdf($id, $date)
    {
        // return '';
        $user = $this->user->find($id);
        $payslip = $this->payroll->findByDate($id,$date);
        return $html = View::make('payroll::pdf2', compact('payslip', 'user'));
    }

     public function view_pdf($id, $date)
    {
        // return '';
        $user = $this->user->find($id);
        $payslip = $this->payroll->findByDate($id,$date);
        return $html = View::make('payroll::pdf2', compact('payslip', 'user'));
    }

    public function getAttrEarning()
    {
        return AttributeModel::earning();
    }

    public function getAttrDeduction()
    {
        return AttributeModel::deduction();
    }
} 