<?php
Route::group(['prefix' => 'admin', 'before' => ['auth', 'admin'], 'namespace' => 'App\Modules\Payroll\Controllers'], function(){
    Route::get('payroll', ['uses' => 'PayRollController@index', 'as' => 'admin.payroll.index']);
    Route::get('payroll/show', ['uses' => 'PayRollController@show', 'as' => 'admin.payroll.show']);
    Route::post('payroll/save/{id}', ['uses' => 'PayRollController@store', 'as' => 'admin.payroll.save']);
    Route::post('payroll/update/{payslip_id}', ['uses' => 'PayRollController@update', 'as' => 'admin.payroll.update']);
    Route::get('payroll/view_pdf/{id?}/{date?}',['uses' => 'PayRollController@view_pdf', 'as' => 'admin.payroll.view_pdf']);
    Route::get('payroll/pdf/{id?}/{date?}',['uses' => 'PayRollController@pdf', 'as' => 'admin.payroll.pdf']);
    Route::controller('payroll', 'PayRollController');
});