<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 10/11/14
 * Time: 14:28
 */

namespace App\Modules\Payroll\Repositories;

use App\Modules\Payroll\Models\PayRoll;

class PayRollRepository {

    public function all() {

    }

    public function delete($id) {

    }

    public function find($id) {

    }

    public function store($data) {
        return PayRoll::create([
            'total_earning' => $data['total_earnings'],
            'overtime' => $data['overtime'],
            'tax' => $data['tax'],
            'late' => $data['late'],
            'total_deduction' => $data['total_deductions'],
            'date' => $data['date'],
            'jht_perusahaan' => $data['jht_perusahaan'],
            'jkk_perusahaan' => $data['jkk_perusahaan'],
            'jkm_perusahaan' => $data['jkm_perusahaan'],
            'jht_karyawan' => $data['jht_karyawan'],
            'kesehatan_perusahaan' => $data['kesehatan_perusahaan'],
            'kesehatan_karyawan' => $data['kesehatan_karyawan'],
            'pensiun_perusahaan' => $data['pensiun_perusahaan'],
            'pensiun_karyawan' => $data['pensiun_karyawan'],
            'user_id' => $data['user_id'],
            'number' => $this->generateNumber($data['user_id'])
        ]);
    }

    public function update($id, $data) {
        $payroll = PayRoll::find($id);

        $payroll->fill([
            'total_earning' => $data['total_earnings'],
            'overtime' => $data['overtime'],
            'tax' => $data['tax'],
            'late' => $data['late'],
            'total_deduction' => $data['total_deductions'],
            'date' => $data['date'],
            'user_id' => $data['user_id'],
            'number' => $this->generateNumber($data['user_id'])
        ]);

        return $payroll->save();
    }

    public function findByDate($id, $date){
        // return 'a';
        return PayRoll::where('user_id', '=', $id)->where('date', '=', $date)->with('values', 'values.attribute')->first();
    }

    public function generateNumber($userId)
    {
        $count = PayRoll::where('user_id', '=', $userId)->count();

        $number = $userId.''.date('m').''.date('y').''.str_pad($count+1, 3, "0", STR_PAD_LEFT);

        return $number;
    }

}
