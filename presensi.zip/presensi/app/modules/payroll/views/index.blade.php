@extends('layouts.default')

@section('content')
<div class="col-md-12">
    <div class="page-header">
        <h3>Payroll</h3>
    </div>
</div>
<div class="col-md-3">
    <form method="get" action="{{ route('admin.payroll.show') }}">
        <div class="form-group col-md-12">
            <select name="user_id" class="form-control" id="user_id">
                @foreach($users as $user)
                <option value="{{ $user->id }}">{{ $user->fullname }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group col-md-7">

            <select class="form-control" name="month" id="month">
                @for($month=1;$month<=12;$month++)
                <option value="{{ $month }}" {{ (date('m') == $month) ? 'selected' : ''}}>{{date("F", mktime(0, 0, 0, $month, 10))}}</option>
                @endfor
            </select>

        </div>
        <div class="form-group col-md-5">
            <select class="form-control" name="year" id="year">
                @for($year=2012;$year<=date('Y');$year++)
                <option value="{{$year}}" {{ (date('Y') == $year) ? 'selected' : ''}}>{{$year}}</option>
                @endfor
            </select>
        </div>
        <br>
        <div class="form-group col-md-12">
            <button class="btn btn-primary btn-block">Pilih</button>
        </div>

    </form>

</div>
@stop