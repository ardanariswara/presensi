<?php
use App\Modules\Payroll\Libraries\CurrencyFormatter;
?>
<html>
<head>
    <title>PDF</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet">    
    <link href="{{ asset('assets/css/print.css') }}" rel="stylesheet">
</head>
<body class="container section" onload="window.print()">

<div class="row">
  <div class="col-xs-4"><h5><img src="{{ asset('assets/img/logo.png') }}" width="175px" style="margin-top: 0px;margin-left:0px"></h5></div>
  <div class="col-xs-8 text-right">
  <div class=""><b>SLIP GAJI</b></div>
  <div class="row">
  <hr/>
        <p>Periode pembayaran : <b> <span class="col-xs-3 pull-right">{{ $payslip->date }}</b></span>
        </p>
        <p >Slip No :
            <span class="col-xs-3 pull-right"><b>{{ $payslip->number }}</b></span>
        </p>
      
        </div>
        </div>
</div>
 <hr/>
<div class="row">
  <div class="col-xs-8">   
  <div class="row">
  <p><span class="col-xs-3">NIP - Nama</span>: <b>{{ $user->nip }} - {{ $user->fullname }}</b></p>  
  <p><span class="col-xs-3">Jabatan</span>: <b>{{ $user->jabatan }}</b></p>  
  
 </div>
</div>
</div>
    <hr/>
<div class="row">  
<div class="col-xs-6">
<div class="header">
        <div class="header-left">
            PENGHASILAN
        </div>
        <div class="header-right">

        </div>
    </div>
    <div class="body">
        <div class="body-left">Gaji Pokok</div>
        <div class="body-right">{{ CurrencyFormatter::format($user->gaji_pokok) }}</div><br>
        <div class="body-left">Lembur</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->overtime)}}</div><br>
        <div class="body-left">BPJS Tenaga Kerja :</div>
        <div class="body-right"><strong>&nbsp;</strong></div><br>
        <div class="body-left"> - JHT</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->jht_perusahaan)}}</div><br>
        <div class="body-left"> - JKK</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->jkk_perusahaan)}}</div><br>
        <div class="body-left"> - JKM</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->jkm_perusahaan)}}</div><br>
        <div class="body-left"> BPJS Kesehatan</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->kesehatan_perusahaan)}}</div><br>
        <div class="body-left">Jaminan Pensiun</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->pensiun_perusahaan)}}</div><br>
        @foreach($payslip->values as $attr)
        @if(isset($attr->attribute) && $attr->attribute->type == 'earning' && $attr->value > 0)
        <div class="body-left">{{ $attr->attribute->name }}</div>
        <div class="body-right">{{ CurrencyFormatter::format($attr->value) }}</div><br>
        @endif
        @endforeach
    </div>
   
   </div>
<div class="col-xs-6"> 
<div class="header">
        <div class="header-left">
            POTONGAN
        </div>
        <div class="header-right">
        </div>
    </div>
    <div class="body">
        <div class="body-left">Pajak PPH 21</div>
        <div class="body-right">{{ CurrencyFormatter::format($payslip->tax)}}</div><br>
        <div class="body-left">Keterlambatan</div>
        <div class="body-right">{{ CurrencyFormatter::format($payslip->late) }}</div><br>
        <div class="body-left"><strong>Perusahaan</strong></div>       
        <div class="body-right"><strong>&nbsp;</strong></div><br>         
        <div class="body-left">BPJS Tenaga Kerja :</div>
        <div class="body-right"><strong>&nbsp;</strong></div><br>
        <div class="body-left"> - JHT</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->jht_perusahaan)}}</div><br>
        <div class="body-left"> - JKK</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->jkk_perusahaan)}}</div><br>
        <div class="body-left"> - JKM</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->jkm_perusahaan)}}</div><br>
        <div class="body-left"> BPJS Kesehatan</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->kesehatan_perusahaan)}}</div><br>
        <div class="body-left">Jaminan Pensiun</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->pensiun_perusahaan)}}</div><br>
        <div class="body-left"><strong>Karyawan</strong></div> 
        <div class="body-right"><strong>&nbsp;</strong></div><br>
        <div class="body-left">BPJS Tenaga Kerja :</div>
        <div class="body-right"><strong>&nbsp;</strong></div><br>
        <div class="body-left"> - JHT</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->jht_karyawan)}}</div><br>
        <div class="body-left"> BPJS Kesehatan</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->kesehatan_karyawan)}}</div><br>
        <div class="body-left">Jaminan Pensiun</div>
        <div class="body-right">{{CurrencyFormatter::format($payslip->pensiun_karyawan)}}</div><br>
        @foreach($payslip->values as $attr)
        @if( $attr->attribute->type == 'deduction' )
        <div class="body-left">{{ $attr->attribute->name }}</div>
        <div class="body-right">{{ CurrencyFormatter::format($attr->value) }}</div><br>
        @endif
        @endforeach
    </div>
   
  </div>

</div>

<div class="row ">
<div class="col-xs-6"> 
 <div class="footer">
        <div class="footer-left">
            Total Pendapatan
        </div>
        <div class="footer-right">
            {{ CurrencyFormatter::format($payslip->total_earning) }}
        </div>
    </div>
    </div>
<div class="col-xs-6"> 
<div class="footer">
        <div class="footer-left">
            Total Potongan
        </div>
        <div class="footer-right">
            {{ CurrencyFormatter::format($payslip->total_deduction) }}
        </div>
    </div>
    </div>
</div>

<div class="row">
<div class="col-xs-6"> 
 <div class="grey-block">
        <div class="footer-left">
            Gaji Diterima 
        </div>
        <div class="footer-right">
          {{ CurrencyFormatter::format($payslip->total_earning - $payslip->total_deduction) }}
        </div>
    </div>
    </div>


</div>


<div class="row section">

@if(!empty($user->bank_account))
                                        

 <div class="col-xs-4">
 <div>
 <br/>
   <p>Ditransfer ke</p>

<div class="row "> 
    @foreach(unserialize($user->bank_account) as $bank)
                                  
  <p><span class="col-xs-5">Bank</span>: <b>{{$bank['bank']}}</b></p>  
  <p><span class="col-xs-5">No. Rekening</span>: <b>{{$bank['norek']}} </b></p>
  <p><span class="col-xs-5">a/n</span>: <b>{{$bank['an']}}</b></p>  
    
  

                               
                                        @endforeach
                                        @endif
  </div>
  </div>
  
</div>


  <div class="col-xs-8 text-center">
  <div class="row">
  <p>Yogyakarta, {{ $payslip->created_at->format('d-m-Y') }}</p>
  <br>
    <div class="col-xs-6">
      
  <p>Diterima oleh</p>


    <div>   
       
        <br><br><br>
        <p><b><u>{{ $user->fullname }}</u></b></p>
    </div>
    </div>

    <div class="col-xs-6">
    
  <p>Disetujui</p>
    <div>   
        <br><br><br>
        <p><b><u>Wahmuji</u></b><br/>
        <b>Direktur Utama</b></p>
    </div>
    </div>
  </div>
  </div>
</div>
</div>
</body>
</html>