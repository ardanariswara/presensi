<?php
$date = $_GET['month'].'-'.$_GET['year'];
?>
@extends('layouts.default')

@section('content')
<div class="col-md-12">
    <div class="page-header">
        <h3>Payroll</h3>
    </div>
</div>
<div class="col-md-3">
    <form method="get" action="{{ route('admin.payroll.show') }}">
        <div class="form-group col-md-12">
            <select name="user_id" class="form-control" id="user_id">
                @foreach($users as $user)
                <option value="{{ $user->id }}" {{ ($_GET['user_id'] == $user->id) ? 'selected' : '' }}>{{ $user->fullname }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group col-md-7">

            <select class="form-control" name="month" id="month">
                @for($month=1;$month<=12;$month++)
                <option value="{{ $month }}" {{ (isset($_GET['month']) && $_GET['month'] == $month) ? 'selected' : ''}}>{{date("F", mktime(0, 0, 0, $month, 10))}}</option>
                @endfor
            </select>

        </div>
        <div class="form-group col-md-5">
            <select class="form-control" name="year" id="year">
                @for($year=2012;$year<=date('Y');$year++)
                <option value="{{$year}}" {{ (isset($_GET['year']) && $_GET['year'] == $year) ? 'selected' : ''}}>{{$year}}</option>
                @endfor
            </select>
        </div>
        <br>
        <div class="form-group col-md-12">
            <button class="btn btn-primary btn-block">Pilih</button>
        </div>
    </form>
    <table class="table">
        <tr>
            <th> Lembur</th>
            <td>{{$overTime}} </td>
        </tr>
        <tr>
            <th> Keterlambatan</th>
            <td>{{$lateTime}} </td>
        </tr>
    </table>
    <br>
    <h4 class="text-center">Akun Bank</h4>
    @if(!empty($findUser->bank_account))
    @foreach(unserialize($findUser->bank_account) as $bank)
    <table class="table">
        <tr>
            <th> Bank</th>
            <td>{{$bank['bank']}} </td>
        </tr>
        <tr>
            <th> A/N</th>
            <td>{{$bank['an']}} </td>
        </tr>
        <tr>
            <th> No. Rekening</th>
            <td>{{$bank['norek']}} </td>
        </tr>
    </table>
    @endforeach
    @endif</div>
{{--$findUser--}}
<div class="col-md-9" id="sheet">
    <input type="hidden" id="user_id" value="{{$findUser->id}}">

    <input type="hidden" id="tunjangan" value="{{$findUser->tunjangan}}">
    <!--over time cell O1-->
    <input type="hidden" data-cell="O1" value="{{$overTime}}" id="overtime">
    <!--late time cell O2-->
    <input type="hidden" data-cell="O2" value="{{$lateTime}}" id="latetime">
     <!--total earning-->
    <input type="hidden" id="total_earning">
    <!--total deductions-->
    <input type="hidden" id="total_deduction">

    <div class="col-md-6">
        <h4 class="text-center">Penghasilan</h4>
        <table class="table table-bordered" id="tambah">
            <tr>
                <th>Gaji Pokok</th>
                <td><input type="text" class="form-control" id="gaji_pokok" value="{{ $findUser->gaji_pokok }}"></td>
            </tr>
            <tr>
                <th>Lembur</th>
                <td><input type="text" class="form-control" id="lembur" value=""  readonly></td>
            </tr>
            <tr>
                <th colspan="2" class="text-center">Tunjangan</th>
            </tr>
            <tr>
                <th>JHT</th>
                <td><input type="text" class="form-control" id="perusahaan_jht1" value="{{ $payslip->jht_perusahaan }}"></td>
            </tr>
            <tr>
                <th>JKK</th>
                <td><input type="text" class="form-control" id="perusahaan_jkk1" value="{{ $payslip->jkk_perusahaan }}"></td>
            </tr>
            <tr>
                <th>JKM</th>
                <td><input type="text" class="form-control" id="perusahaan_jkm1" value="{{ $payslip->jkm_perusahaan }}"></td>
            </tr>
            <tr>
                <th>BPJS Kesehatan</th>
                <td><input type="text" class="form-control" id="perusahaan_kesehatan1" value="{{ $payslip->kesehatan_perusahaan }}"></td>
            </tr>
              <tr>
                <th>Jaminan Pensiun</th>
                <td><input type="text" class="form-control" id="perusahaan_pensiun" value="{{ $findUser->tunjangan ? $findUser->pensiunPerusahaan() : 0 }}" ></td>
            </tr>
           <!--  <tr>
               <th>Tunjangan Ketenagakerjaan</th>
               <td><input type="text" class="form-control" id="bpjskk" value="0" readonly></td>
           </tr> -->
            <tbody id="attr-penambah">
            @foreach($payslip->values as $a => $earning)
                @if(isset($earning->attribute)&&$earning->attribute->type === 'earning')
                <tr id="attr">
                    <th>{{ $earning->attribute->name }}</th>
                    <td>
                        <div class="button-min">
                            <a href="#" class="btn btn-default btn-sm" id="remove-attr"><i class="glyphicon glyphicon-minus"></i></a>
                        </div>
                        <input type="text" class="form-control" id="attribute_values" name="attribute_values" data-fix="{{ $earning->attribute->is_fix }}" value="{{ $earning->value }}">
                        <input type="hidden" name="attribute_value_id" id="attribute_value_id" value="{{ $earning->id }}">
                        <input type="hidden" name="attributes" id="attributes" value="{{ $earning->attribute->id }}">
                    </td>
                </tr>
                @endif
            @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="2" class="text-center"><button class="btn btn-default btn-sm" id="btn-add-earning">Tambah Atribute</button></td>
                </tr>
            </tfoot>
        </table>
        <script type="text/x-handlebars-template" id="template-attr">
            <tr id="attr">
                <td><div class="button-min" style="display: none;">
                        <a href="#" class="btn btn-default btn-sm" id="remove-attr"><i class="fa fa-minus"></i></a>
                    </div>
                    <select class="form-control" name="attributes" id="attributes">
                    @{{#each items}}
                        <option value="@{{id}}" data-key="@{{@index}}">@{{name}} </option>
                    @{{/each}}
                    </select>
                </td>
                <td><input class="form-control" name="attribute_values" id="attribute_values" type="text" value="@{{items.0.value}}"></td>
            </tr>
        </script>
    </div>
    <div class="col-md-6">
        <h4 class="text-center">Potongan</h4>
        <table class="table table-bordered" id="potongan">
            <tr>
                <th>Pajak 21</th>
                <td><input type="text" class="form-control" id="tax" value=""  readonly></td>
            </tr>
            <tr>
                <th>Keterlambatan</th>
                <td><input type="text" class="form-control" id="telat" readonly></td>
            </tr>
            <tr>
                <th colspan="2" class="text-center">Perusahaan</th>
            </tr>
            <tr>
                <th>JHT</th>
                <td><input type="text" class="form-control" id="perusahaan_jht" value="{{ $payslip->jht_perusahaan }}"></td>
            </tr>
            <tr>
                <th>JKK</th>
                <td><input type="text" class="form-control" id="perusahaan_jkk" value="{{ $payslip->jkk_perusahaan }}"></td>
            </tr>
            <tr>
                <th>JKM</th>
                <td><input type="text" class="form-control" id="perusahaan_jkm" value="{{ $payslip->jkm_perusahaan }}"></td>
            </tr>
            <tr>
                <th>BPJS Kesehatan</th>
                <td><input type="text" class="form-control" id="perusahaan_kesehatan" value="{{ $payslip->kesehatan_perusahaan }}"></td>
            </tr>
            <tr>
                <th>Jaminan Pensiun</th>
                <td><input type="text" class="form-control" id="perusahaan_pensiun" value="{{ $findUser->tunjangan ? $findUser->pensiunPerusahaan() : 0 }}" ></td>
            </tr>
            <tr>
                <th colspan="2" class="text-center">Karyawan</th>
            </tr>
            <tr>
                <th>JHT</th>
                <td><input type="text" class="form-control" id="karyawan_jht" value="{{ $payslip->jht_karyawan }}"></td>
            </tr>
            <tr>
                <th>BPJS Kesehatan</th>
                <td><input type="text" class="form-control" id="karyawan_kesehatan" value="{{ $payslip->kesehatan_karyawan }}"></td>
            </tr>
            <tr>
                <th>Jaminan Pensiun</th>
                <td><input type="text" class="form-control" id="karyawan_pensiun" value="{{ $findUser->tunjangan ? $findUser->pensiunKaryawan() : 0 }}" ></td>
            </tr>
            <tbody id="attr-pengurang">
            @foreach($payslip->values as $b => $deduction)
            @if(isset($deduction->attribute) && $deduction->attribute->type === 'deduction')
            <tr id="attr">
                <th>{{ $deduction->attribute->name }}</th>
                <td>
                    <div class="button-min">
                        <a href="#" class="btn btn-default btn-sm" id="remove-attr"><i class="glyphicon glyphicon-minus"></i></a>
                    </div>
                    <input type="text" class="form-control" id="attribute_values" name="attribute_values" value="{{ $deduction->value }}">
                    <input type="hidden" name="attribute_value_id" id="attribute_value_id" value="{{ $deduction->id }}">
                    <input type="hidden" name="attributes" id="attributes" value="{{ $deduction->attribute->id }}">
                </td>
            </tr>
            @endif
            @endforeach
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="2" class="text-center"><button class="btn btn-default btn-sm" id="btn-add-deduction">Tambah Atribute</button></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <div class="col-md-12">
        <hr>
        <div class="form-group col-md-6 pull-left">
            <h4>&nbsp;</h4>
            <button type="button" id="update" class="btn btn-primary">Update</button>
            <button type="button" id="refresh" class="btn btn-primary" onclick="Payroll.init()">Refresh</button>
            <!--<button type="button" id="view_print" class="btn btn-default" data-url="{{route('admin.payroll.view_pdf', [$findUser->id, $date])}}">Preview Print</button>-->            
            <button type="button" id="print" class="btn btn-default" data-url="{{route('admin.payroll.pdf', [$findUser->id, $date])}}">Print</button>
        </div>
        <div class="form-group col-md-6 pull-right">
            <h4><b>Total Gaji</b></h4>
            <input type="text" class="form-control" data-cell="Z10" id="total_gaji" readonly >

        </div>

    </div> 

</canvas> 
</div>
@stop
@section('scripts')
<script src="//code.jquery.com/ui/1.11.3/jquery-ui.js"></script>
<script type="text/javascript" src="/assets/js/payroll4.js"></script>
<script>
    $(document).ready(function(){
        $('table>tbody#attr-penambah, table>tbody#attr-pengurang').sortable();
        // $('table>tbody').disableSelection();
        Payroll.init();

        var $btnAddEarning = $('#btn-add-earning'),
            $btnAddDeduction = $('#btn-add-deduction');

        $btnAddEarning.on({
            click: function(){
                Payroll.addAttrEarning();
            }
        })

        $btnAddDeduction.on({
            click: function(){
                Payroll.addAttrDeduction();
            }
        })
        var $update = $('button#update');
        var url_update = '{{route('admin.payroll.update', [$payslip->id])}}';
        $update.on({
            click: function(){
                Payroll.update(url_update);
            }
        })
    })


</script>
@stop