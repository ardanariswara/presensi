<?php
/**
 * Created by PhpStorm.
 * User: Vicky
 * Date: 10/11/14
 * Time: 14:26
 */

namespace App\Modules\Payroll\Models;


use Illuminate\Database\Eloquent\Model;

class PayRoll extends Model {

    protected $table = 'pay_slip';

    protected $fillable = ['total_earning', 'overtime', 'tax', 'late', 'total_deduction', 'date', 'user_id', 'number', 'jht_perusahaan', 'jkk_perusahaan', 'jkm_perusahaan', 'jht_karyawan', 'kesehatan_perusahaan', 'kesehatan_karyawan',  'pensiun_perusahaan',  'pensiun_karyawan'];

    public function values()
    {
        return $this->hasMany('App\Modules\Attributes\Models\AttributeValue', 'payslip_id');
    }

}
